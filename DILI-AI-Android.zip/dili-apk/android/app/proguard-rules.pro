-keep class com.giyosiddin.diliai.** { *; }
-keepclassmembers class com.giyosiddin.diliai.AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn okio.**

const RamadanPage={
  render(){
    const ram=DB.get('ramadan')||{};const now=new Date();const today=now.toDateString();
    const fasting=ram.fasting||[];const prayers=ram.prayers||[];
    const todayFast=fasting.find(f=>new Date(f.date).toDateString()===today);
    const todayPrayers=prayers.filter(p=>new Date(p.date).toDateString()===today);
    const totalFast=fasting.filter(f=>f.kept).length;
    const prayerNames=['Bomdod','Peshin','Asr','Shom','Xufton'];
    const prayerEmojis=['🌅','☀️','🌤️','🌇','🌙'];
    const isRam=Notif._isRamadan();
    const start=new Date(ram.startDate||'2025-03-01');const end=new Date(ram.endDate||'2025-03-30');
    const dayNum=isRam?Math.ceil((now-start)/86400000)+1:0;
    const totalDays=Math.ceil((end-start)/86400000)+1;

    document.getElementById('page-ramadan').innerHTML=`
      <div class="ph"><h1>🌙 Ramazon</h1><p>${isRam?`${dayNum}-kun (${totalDays} kundan)`:'Ramazon vaqtlarini kuting'}</p></div>
      <div class="px">
        ${isRam?`<div class="ramadan-card mb16">
          <div class="flex ac jb mb14">
            <div><div style="font-size:24px;font-weight:800;color:#4ade80">${dayNum}-kun</div><div style="font-size:13px;color:rgba(74,222,128,.7)">Ramazon ${new Date().getFullYear()}</div></div>
            <div style="text-align:right"><div style="font-size:22px;font-weight:700;color:#4ade80">${totalFast}</div><div style="font-size:12px;color:rgba(74,222,128,.7)">Kun ro'za tutildi</div></div>
          </div>
          <div class="pb"><div class="pf" style="width:${Math.round((dayNum/totalDays)*100)}%;background:linear-gradient(90deg,#4ade80,#22c55e)"></div></div>
          <div style="font-size:11px;color:rgba(74,222,128,.6);margin-top:6px">${Math.round((dayNum/totalDays)*100)}% ramazon tugadi</div>
        </div>`:`<div class="card mb16" style="text-align:center;padding:24px"><div style="font-size:40px;margin-bottom:12px">🌙</div><div style="font-size:16px;font-weight:600">Ramazon sanalarini kiriting</div></div>`}

        <div class="sl">Bugungi holat</div>
        <div class="card mb16">
          <div class="flex ac jb mb16">
            <div>
              <div style="font-size:16px;font-weight:700">Bugungi ro'za</div>
              <div style="font-size:13px;color:var(--t2)">${todayFast?.kept?'✅ Tutildi':todayFast?'❌ Tutilmadi':'Belgilanmagan'}</div>
            </div>
            <div class="flex gap8">
              <button class="btn btn-g" style="padding:9px 14px;font-size:13px" onclick="RamadanPage.logFast(true)">✅ Tutdim</button>
              <button class="btn btn-d" style="padding:9px 14px;font-size:13px" onclick="RamadanPage.logFast(false)">❌ Tutmadim</button>
            </div>
          </div>
          <div style="font-size:14px;font-weight:600;margin-bottom:12px">Namozlar (${todayPrayers.length}/5)</div>
          <div class="flex jb gap8">
            ${prayerNames.map((name,i)=>{
              const done=todayPrayers.some(p=>p.name===name);
              return`<div style="text-align:center;cursor:pointer" onclick="RamadanPage.logPrayer('${name}')">
                <div style="width:44px;height:44px;border-radius:14px;background:${done?'rgba(48,209,88,.2)':'var(--glass)'};border:2px solid ${done?'var(--green)':'var(--border)'};display:flex;align-items:center;justify-content:center;font-size:18px;margin:0 auto 5px;transition:all .2s">${prayerEmojis[i]}</div>
                <div style="font-size:10px;font-weight:600;color:${done?'var(--green)':'var(--t2)'}">${name}</div>
              </div>`;
            }).join('')}
          </div>
        </div>

        <div class="sl">Vaqtlar (Toshkent)</div>
        <div class="lg mb16">
          ${[['🌙 Saharlik','04:45'],['🌅 Bomdod','05:15'],['☀️ Peshin','12:45'],['🌤️ Asr','16:30'],['🌇 Shom','19:15'],['🌙 Xufton','20:45'],['🌅 Iftorlik','19:18']].map(([n,t])=>`<div class="li"><div class="li-t">${n}</div><div style="font-size:15px;font-weight:700;color:var(--green)">${t}</div></div>`).join('')}
        </div>

        <div class="sl">Ramazon statistikasi</div>
        <div class="g2 mb16">
          <div class="sc"><div style="font-size:22px">🌙</div><div class="sv tc-green">${totalFast}</div><div class="slb">Ro'za kunlar</div></div>
          <div class="sc"><div style="font-size:22px">🕌</div><div class="sv" style="color:var(--gold)">${prayers.filter(p=>fasting.some(f=>new Date(f.date).toDateString()===new Date(p.date).toDateString())).length}</div><div class="slb">Jami namoz</div></div>
        </div>

        <div class="sl">AI Ramazon xulosasi</div>
        <div class="card mb16">
          <div id="ram-report-text" style="font-size:14px;color:var(--t2);line-height:1.6;margin-bottom:14px">AI sizning Ramazon holatingizni tahlil qiladi va maslahat beradi.</div>
          <button class="btn btn-r btn-w" onclick="RamadanPage.getAIReport()">🤖 AI Xulosasi olish</button>
        </div>

        <div class="sl">Sanalarni sozlash</div>
        <div class="card mb16">
          <div class="g2">
            <div class="fg"><label class="fl">Ramazon boshlanishi</label><input type="date" id="ram-start" value="${ram.startDate||'2025-03-01'}" onchange="RamadanPage.saveSettings()"></div>
            <div class="fg"><label class="fl">Ramazon tugashi</label><input type="date" id="ram-end" value="${ram.endDate||'2025-03-30'}" onchange="RamadanPage.saveSettings()"></div>
          </div>
        </div>
        <div style="height:16px"></div>
      </div>`;
  },
  logFast(kept){
    const today=new Date().toDateString();const fasting=DB.get('ramadan.fasting')||[];
    const idx=fasting.findIndex(f=>new Date(f.date).toDateString()===today);
    const entry={id:uid(),date:Date.now(),kept};
    if(idx>-1)fasting[idx]=entry;else fasting.push(entry);
    DB.set('ramadan.fasting',fasting);
    showToast(kept?'✅ Ro\'za belgilandi':'Belgilandi','success');
    if(kept)Sound.play('success');
    this.render();
  },
  logPrayer(name){
    const today=new Date().toDateString();const prayers=DB.get('ramadan.prayers')||[];
    const alreadyDone=prayers.some(p=>new Date(p.date).toDateString()===today&&p.name===name);
    if(alreadyDone){DB.set('ramadan.prayers',prayers.filter(p=>!(new Date(p.date).toDateString()===today&&p.name===name)));showToast(`${name} bekor qilindi`,'default');}
    else{DB.push('ramadan.prayers',{id:uid(),name,date:Date.now()});showToast(`${name} namozi ✅`,'success');Sound.play('default');}
    this.render();
  },
  async getAIReport(){
    const el=document.getElementById('ram-report-text');
    if(el)el.textContent='Tayyorlanmoqda...';
    const report=await AI.generateReport('ramadan');
    if(el&&report)el.textContent=report;
  },
  saveSettings(){
    DB.set('ramadan.startDate',document.getElementById('ram-start')?.value||'2025-03-01');
    DB.set('ramadan.endDate',document.getElementById('ram-end')?.value||'2025-03-30');
    showToast('Sanalar saqlandi ✅','success');this.render();
  }
};

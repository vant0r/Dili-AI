const Sound={
  ctx:null,
  _ctx(){if(!this.ctx)this.ctx=new(window.AudioContext||window.webkitAudioContext)();return this.ctx},
  beep(freq=440,dur=0.3,type='sine',vol=0.3){
    try{
      const ctx=this._ctx();const osc=ctx.createOscillator();const gain=ctx.createGain();
      osc.connect(gain);gain.connect(ctx.destination);
      osc.type=type;osc.frequency.value=freq;
      gain.gain.setValueAtTime(vol,ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+dur);
      osc.start(ctx.currentTime);osc.stop(ctx.currentTime+dur);
    }catch(e){}
  },
  play(name){
    if(!DB.get('settings.notifications.sound'))return;
    const patterns={
      default:()=>this.beep(660,.2,'sine',.3),
      task:()=>{this.beep(523,.15,'sine',.3);setTimeout(()=>this.beep(659,.15,'sine',.3),160);setTimeout(()=>this.beep(784,.3,'sine',.3),320)},
      success:()=>{this.beep(523,.1,'sine',.3);setTimeout(()=>this.beep(659,.1,'sine',.3),120);setTimeout(()=>this.beep(784,.1,'sine',.3),240);setTimeout(()=>this.beep(1047,.3,'sine',.3),360)},
      health:()=>{this.beep(440,.2,'sine',.25);setTimeout(()=>this.beep(550,.2,'sine',.25),250)},
      ramadan:()=>{for(let i=0;i<5;i++)setTimeout(()=>this.beep(440+i*55,.3,'sine',.2),i*200)},
      pomodoro:()=>{this.beep(880,.1,'square',.2);setTimeout(()=>this.beep(660,.1,'square',.2),150);setTimeout(()=>this.beep(440,.4,'square',.2),300)},
      motivation:()=>{[523,587,659,698,784].forEach((f,i)=>setTimeout(()=>this.beep(f,.15,'sine',.25),i*100))},
      error:()=>{this.beep(220,.3,'sawtooth',.2);setTimeout(()=>this.beep(196,.3,'sawtooth',.2),350)}
    };
    const fn=patterns[name]||patterns.default;fn();
  }
};

const Notif={
  _scheduled:[],
  async request(){
    if('Notification' in window&&Notification.permission==='default')
      await Notification.requestPermission();
    return Notification.permission==='granted';
  },
  send(title,body,icon='🔔',sound='default'){
    Sound.play(sound);
    vibrate([100,50,100]);
    if('Notification' in window&&Notification.permission==='granted'){
      try{new Notification(title,{body,icon:'/icons/icon-192.png',badge:'/icons/badge-72.png',vibrate:[200,100,200]});}catch(e){}
    }
    showToast(`${icon} ${title}: ${body}`,'default');
  },
  scheduleAll(){
    this._scheduled.forEach(id=>clearTimeout(id));
    this._scheduled=[];
    const n=DB.get('settings.notifications');
    if(!n)return;
    const now=new Date();
    const scheduleAt=(h,m,fn)=>{
      const t=new Date();t.setHours(h,m,0,0);
      if(t<=now)t.setDate(t.getDate()+1);
      const diff=t-now;
      const id=setTimeout(()=>{fn();this.scheduleAt(h,m,fn);},diff);
      this._scheduled.push(id);
    };
    if(n.health){
      scheduleAt(8,0,()=>this.send('💧 Suv iching!','Ertalabki suv iste\'moli vaqti','💧','health'));
      scheduleAt(12,0,()=>this.send('💧 Tushlik vaqti!','Suv ichishni unutmang','💧','health'));
      scheduleAt(18,0,()=>this.send('😴 Uyqu rejimi','Kechqurun 10da yotishni rejalashtiring','😴','health'));
    }
    if(n.tasks){
      scheduleAt(9,0,()=>{
        const tasks=DB.get('tasks')||[];const pending=tasks.filter(t=>!t.done).length;
        if(pending>0)this.send('✅ Vazifalar','Bugun '+pending+' ta bajarilmagan vazifa bor','✅','task');
      });
    }
    if(n.motivation){
      const quotes=["Bugun ham ajoyib inson bo'l! 💪","Har bir qadam maqsadga yaqinlashtiradi 🎯","Sen buni uddalay olasan! 🌟","Kuchli odam qiyinchiliklardan qo'rqmaydi 🔥","Bugun kechagidan yaxshiroq bo'l ⭐"];
      scheduleAt(7,0,()=>this.send('💪 Motivatsiya',quotes[Math.floor(Math.random()*quotes.length)],'💪','motivation'));
    }
    if(n.ramadan){
      const ram=DB.get('ramadan');
      if(ram&&this._isRamadan()){
        scheduleAt(4,30,()=>this.send('🌙 Saharlik','Saharlik vaqti yaqinlashmoqda! 30 daqiqa qoldi','🌙','ramadan'));
        scheduleAt(19,30,()=>this.send('🌅 Iftorlik','Iftorlik vaqti yaqinlashmoqda! 10 daqiqa qoldi','🌅','ramadan'));
      }
    }
  },
  _isRamadan(){
    const ram=DB.get('ramadan');if(!ram)return false;
    const now=Date.now();const start=new Date(ram.startDate).getTime();const end=new Date(ram.endDate).getTime();
    return now>=start&&now<=end;
  },
  scheduleAt(h,m,fn){
    const now=new Date();const t=new Date();t.setHours(h,m,0,0);
    if(t<=now)t.setDate(t.getDate()+1);
    const id=setTimeout(()=>{fn();this.scheduleAt(h,m,fn);},t-now);
    this._scheduled.push(id);
  }
};

const AI={
  URL:'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
  async ask(prompt,sys=''){
    const key=DB.get('settings.gemini.api_key');
    if(!key){showToast("Gemini API kaliti yo'q! Sozlamalarga o'ting",'error');return null}
    const temp=DB.get('settings.gemini.temperature')||0.7;
    const body={contents:[{parts:[{text:(sys?sys+'\n\n':'')+prompt}]}],generationConfig:{temperature:temp,maxOutputTokens:2048}};
    try{
      const r=await fetch(`${this.URL}?key=${key}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      if(!r.ok){const e=await r.json();throw new Error(e.error?.message||'API xatosi')}
      const d=await r.json();
      DB.set('analytics.ai_queries',(DB.get('analytics.ai_queries')||0)+1);
      return d.candidates?.[0]?.content?.parts?.[0]?.text||'';
    }catch(e){showToast('AI xatosi: '+e.message,'error');return null}
  },
  sys(){
    const u=DB.get('user');const tasks=DB.get('tasks')||[];const fin=DB.get('finance');
    const ram=DB.get('ramadan');const isRam=Notif._isRamadan();
    const pending=tasks.filter(t=>!t.done).length;
    return`Sen DILI AI - ${u.name}ning shaxsiy AI yordamchisissan. Har doim O'zbek tilida qisqa, aniq va foydali javob ber. Emoji ishlat. Bugun: ${new Date().toLocaleDateString('uz')}. ${isRam?'Hozir Ramazon oyi - fasting va ibodat haqida ham maslahat ber.':''} Ma'lumotlar: ${pending} ta bajarilmagan vazifa, balans: ${fmtMoney(fin?.balance,fin?.currency)}.`
  },
  async generateReport(type){
    const prompts={
      daily:()=>{
        const tasks=DB.get('tasks')||[];const fin=DB.get('finance');const health=DB.get('health')||{};
        const today=new Date().toDateString();
        const todayWater=(health.water||[]).filter(w=>new Date(w.time).toDateString()===today).reduce((s,w)=>s+w.amount,0);
        const todayTasks=tasks.filter(t=>t.doneAt&&new Date(t.doneAt).toDateString()===today).length;
        const todaySleep=(health.sleep||[]).find(s=>new Date(s.date).toDateString()===today);
        return`Bugun ${new Date().toLocaleDateString('uz')} uchun qisqa AI hisobot yoz (O'zbek tilida, 150 so'zdan oshmasin):
Bajarilgan vazifalar: ${todayTasks}
Suv iste'moli: ${todayWater}ml
Uyqu: ${todaySleep?todaySleep.hours+' soat':'kiritilmagan'}
Balans: ${fmtMoney(fin?.balance,fin?.currency)}
Xulosa va tavsiyalar ber.`;
      },
      weekly:()=>{
        const tasks=DB.get('tasks')||[];const fin=DB.get('finance');
        const week=Date.now()-7*86400000;
        const weekTasks=tasks.filter(t=>t.doneAt&&t.doneAt>week).length;
        const txs=(fin?.transactions||[]).filter(t=>t.date>week);
        const income=txs.filter(t=>t.type==='kirim').reduce((s,t)=>s+t.amount,0);
        const expense=txs.filter(t=>t.type==='chiqim').reduce((s,t)=>s+t.amount,0);
        return`So'ngi 7 kun uchun haftalik AI hisobot yoz (O'zbek tilida, 200 so'zdan oshmasin):
Bajarilgan vazifalar: ${weekTasks}
Haftalik kirim: ${fmtMoney(income)}
Haftalik chiqim: ${fmtMoney(expense)}
Streak: ${DB.get('analytics.login_streak')} kun
Xulosa, tavsiya va keyingi hafta uchun reja ber.`;
      },
      ramadan:()=>{
        const ram=DB.get('ramadan')||{};const fasting=ram.fasting||[];const prayers=ram.prayers||[];
        const today=new Date().toDateString();
        const todayFast=fasting.find(f=>new Date(f.date).toDateString()===today);
        const todayPrayers=prayers.filter(p=>new Date(p.date).toDateString()===today);
        return`Ramazon oyi hisoboti yoz (O'zbek tilida, 150 so'zdan oshmasin):
Bugungi ro'za: ${todayFast?'✅ Tutildi':'❌ Tutilmadi'}
Bugungi namozlar: ${todayPrayers.length}/5
Umumiy ro'za kunlar: ${fasting.filter(f=>f.kept).length}
Ruhiy maslahat va duo ber.`;
      },
      nutrition:()=>{
        const today=new Date().toDateString();const meals=DB.get('nutrition.meals')||[];
        const todayMeals=meals.filter(m=>new Date(m.date).toDateString()===today);
        const totalCal=todayMeals.reduce((s,m)=>s+m.calories,0);
        const goal=DB.get('nutrition.dailyGoal')||{calories:2000};
        return`Bugungi ovqatlanish hisoboti yoz (O'zbek tilida, 100 so'zdan oshmasin):
Jami kaloriya: ${totalCal} / ${goal.calories} kcal
Ovqatlar soni: ${todayMeals.length}
Maqsad: ${Math.round((totalCal/goal.calories)*100)}% bajarildi
Tavsiya va maslahat ber.`;
      }
    };
    const prompt=prompts[type]?.();
    if(!prompt)return null;
    showToast('AI hisobot tayyorlanmoqda...','default');
    return await this.ask(prompt);
  }
};

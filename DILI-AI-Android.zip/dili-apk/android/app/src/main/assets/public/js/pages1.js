const AIPage={msgs:[],typing:false,
render(){
  const hasKey=!!DB.get('settings.gemini.api_key');
  document.getElementById('page-ai').innerHTML=`
    <div style="display:flex;flex-direction:column;height:100vh;height:100dvh">
      <div style="padding:52px 20px 14px;background:var(--bg);border-bottom:1px solid var(--border);flex-shrink:0">
        <div class="flex ac jb">
          <div class="flex ac gap12">
            <div style="width:40px;height:40px;background:linear-gradient(135deg,var(--blue),var(--purple));border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:20px">🤖</div>
            <div><div style="font-weight:700;font-size:16px">DILI AI</div><div style="font-size:11px;color:var(--green);font-weight:500">● gemini-2.5-flash</div></div>
          </div>
          <div class="flex gap8">
            <button class="btn btn-s" style="padding:7px 11px;font-size:12px" onclick="AIPage.getReport()">📊 Hisobot</button>
            <button class="btn btn-s" style="padding:7px 11px;font-size:12px" onclick="AIPage.clear()">🗑️</button>
          </div>
        </div>
      </div>
      ${!hasKey?`<div style="margin:14px 18px;padding:14px;background:rgba(255,159,10,.1);border:1px solid rgba(255,159,10,.3);border-radius:var(--r2)"><div style="font-size:13px;font-weight:700;margin-bottom:5px">⚠️ API kaliti kerak</div><button class="btn btn-p btn-w" style="padding:9px;font-size:13px" onclick="Nav.go('settings')">⚙️ Sozlamalarga o'tish</button></div>`:''}
      <div id="ai-msgs" style="flex:1;overflow-y:auto;padding:14px 18px;display:flex;flex-direction:column;gap:11px">
        ${this.msgs.length===0?`<div style="text-align:center;padding:28px 0"><div style="font-size:52px;margin-bottom:14px">🤖</div><div style="font-size:20px;font-weight:700;margin-bottom:7px">DILI AI v3.0</div><div style="font-size:13px;color:var(--t2);line-height:1.6;max-width:280px;margin:0 auto">Savol bering, hisobot so'rang yoki maslahat oling!</div></div>`:''}
        ${this.msgs.map(m=>this._msgHtml(m)).join('')}
      </div>
      <div id="ai-typing" style="display:none;padding:0 18px 8px;flex-shrink:0"><div style="display:inline-flex;align-items:center;gap:8px;background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:9px 13px"><div style="display:flex;gap:3px">${[0,.2,.4].map(d=>`<div style="width:6px;height:6px;background:var(--t2);border-radius:50%;animation:bounce 1.2s ease-in-out infinite ${d}s"></div>`).join('')}</div><span style="font-size:13px;color:var(--t2)">DILI yozmoqda...</span></div></div>
      <div style="padding:10px 18px;padding-bottom:calc(var(--nav)+14px);background:var(--bg);border-top:1px solid var(--border);flex-shrink:0">
        <div style="display:flex;gap:7px;overflow-x:auto;scrollbar-width:none;margin-bottom:10px">
          ${['Bugungi hisobot','Haftalik xulosa','Ramazon maslahat','Pomodoro reja','Kalori tahlil','Motivatsiya'].map(q=>`<div class="chip" onclick="AIPage.quick('${q}')">${q}</div>`).join('')}
        </div>
        <div class="flex gap8 ac">
          <textarea id="ai-inp" placeholder="Savolingizni yozing..." style="flex:1;resize:none;max-height:96px;min-height:42px;overflow:auto;border-radius:var(--r2)" rows="1" onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();AIPage.send()}" oninput="this.style.height='auto';this.style.height=this.scrollHeight+'px'"></textarea>
          <button class="btn btn-p" style="width:42px;height:42px;padding:0;border-radius:50%;flex-shrink:0" onclick="AIPage.send()"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>
        </div>
      </div>
    </div>`;
},
_msgHtml(m){const isU=m.role==='user';return`<div style="display:flex;justify-content:${isU?'flex-end':'flex-start'};gap:7px;align-items:flex-end"><div style="max-width:78%;padding:11px 14px;border-radius:${isU?'18px 18px 4px 18px':'18px 18px 18px 4px'};background:${isU?'var(--blue)':'var(--card)'};border:${isU?'none':'1px solid var(--border)'};font-size:14px;line-height:1.6;white-space:pre-wrap;word-break:break-word">${esc(m.content)}<div style="font-size:10px;color:${isU?'rgba(255,255,255,.5)':'var(--t3)'};margin-top:3px">${fmtTime(m.time)}</div></div></div>`},
async send(){const inp=document.getElementById('ai-inp');const text=inp?.value?.trim();if(!text||this.typing)return;inp.value='';inp.style.height='auto';this._add('user',text);this.typing=true;document.getElementById('ai-typing').style.display='block';this._scroll();const reply=await AI.ask(text,AI.sys());document.getElementById('ai-typing').style.display='none';this.typing=false;if(reply)this._add('assistant',reply);this._scroll()},
quick(t){const inp=document.getElementById('ai-inp');if(inp){inp.value=t;this.send();}},
async getReport(){
  const overlay=document.createElement('div');overlay.className='mo show';
  overlay.innerHTML=`<div class="modal"><div class="mh"></div><h2>📊 AI Hisobot</h2><div style="display:flex;flex-direction:column;gap:10px">
    ${[['daily','📅 Bugungi hisobot'],['weekly','📆 Haftalik xulosa'],['ramadan','🌙 Ramazon hisoboti'],['nutrition','🍽️ Ovqatlanish tahlili']].map(([t,l])=>`<button class="btn btn-s btn-w" style="justify-content:flex-start;padding:13px 16px" onclick="AIPage.runReport('${t}');this.closest('.mo').remove()">${l}</button>`).join('')}
    <button class="btn btn-d btn-w" onclick="this.closest('.mo').remove()">Bekor</button>
  </div></div>`;
  document.body.appendChild(overlay);overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.remove()});
},
async runReport(type){if(!DB.get('settings.gemini.api_key'))return showToast('API kaliti kerak!','error');const r=await AI.generateReport(type);if(r){this._add('user',`📊 ${type} hisoboti`);this._add('assistant',r);Nav.go('ai');}},
_add(role,content){const m={role,content,time:Date.now()};this.msgs.push(m);const c=document.getElementById('ai-msgs');if(c){if(this.msgs.length===1)c.innerHTML='';const d=document.createElement('div');d.innerHTML=this._msgHtml(m);c.appendChild(d.firstElementChild);}},
_scroll(){const c=document.getElementById('ai-msgs');if(c)setTimeout(()=>c.scrollTop=c.scrollHeight,80)},
clear(){this.msgs=[];this.render()}
};

const TasksPage={filter:'all',render(){
  const tasks=DB.get('tasks')||[];const done=tasks.filter(t=>t.done).length;
  const filtered=this.filter==='all'?tasks:this.filter==='active'?tasks.filter(t=>!t.done):tasks.filter(t=>t.done);
  document.getElementById('page-tasks').innerHTML=`
    <div class="ph"><div class="flex ac jb"><div><h1>✅ Vazifalar</h1><p>${done}/${tasks.length} bajarildi</p></div><button class="btn btn-p" style="padding:9px 15px;font-size:14px" onclick="TasksPage.openAdd()">+ Qo'shish</button></div>
    ${tasks.length>0?`<div class="pb mt12"><div class="pf" style="width:${tasks.length?Math.round((done/tasks.length)*100):0}%"></div></div>`:''}
    <div class="flex gap7 mt12">${['all','active','done'].map(f=>`<div class="chip ${this.filter===f?'on':''}" onclick="TasksPage.filter='${f}';TasksPage.render()">${f==='all'?'Hammasi':f==='active'?'Faol':'Bajarilgan'}</div>`).join('')}
    <button class="btn btn-s" style="padding:5px 10px;font-size:12px" onclick="DB.exportCSV('tasks')">📥</button></div></div>
    <div class="px">${filtered.length===0?`<div class="es"><div class="es-ic">✅</div><h3>Vazifalar yo'q</h3></div>`:`<div style="display:flex;flex-direction:column;gap:9px">${filtered.map(t=>this._card(t)).join('')}</div>`}<div style="height:16px"></div></div>
    <div class="mo" id="task-modal"><div class="modal"><div class="mh"></div><h2 id="tm-t">Yangi vazifa</h2><input type="hidden" id="t-id">
    <div class="fg"><label class="fl">Sarlavha *</label><input id="t-title" placeholder="Vazifa nomini kiriting..."></div>
    <div class="fg"><label class="fl">Tavsif</label><textarea id="t-desc" rows="3" style="resize:none" placeholder="Qo'shimcha ma'lumot..."></textarea></div>
    <div class="g2"><div class="fg"><label class="fl">Muhimlik</label><select id="t-pri"><option value="past">Past</option><option value="o'rta" selected>O'rta</option><option value="yuqori">Yuqori</option></select></div><div class="fg"><label class="fl">Muddat</label><input id="t-due" type="date"></div></div>
    <div class="fg"><label class="fl">Kategoriya</label><input id="t-cat" placeholder="Ish, Shaxsiy..."></div>
    <div style="display:flex;gap:9px;margin-top:6px"><button class="btn btn-s f1" onclick="closeModal('task-modal')">Bekor</button><button class="btn btn-p f1" onclick="TasksPage.save()">Saqlash</button></div>
    </div></div>
    <button class="fab" onclick="TasksPage.openAdd()"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`;
},
_card(t){const pc=t.priority==='yuqori'?'var(--red)':t.priority==="o'rta"?'var(--orange)':'var(--blue)';
  return`<div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r3);padding:15px;border-left:3px solid ${pc};opacity:${t.done?.6:1}"><div class="flex ac gap12"><div onclick="TasksPage.toggle('${t.id}')" style="width:23px;height:23px;border:2px solid ${t.done?'var(--green)':'var(--border2)'};border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0;background:${t.done?'rgba(48,209,88,.18)':'transparent'};transition:all .2s">${t.done?'<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>':''}</div><div style="flex:1;min-width:0"><div style="font-size:15px;font-weight:600;${t.done?'text-decoration:line-through;color:var(--t2)':''}">${esc(t.title)}</div>${t.desc?`<div style="font-size:13px;color:var(--t2);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(t.desc)}</div>`:''}<div class="flex ac gap7 mt8">${t.dueDate?`<span class="badge ${new Date(t.dueDate)<new Date()&&!t.done?'b-red':'b-blue'}">📅 ${fmt(t.dueDate)}</span>`:''}${t.category?`<span class="badge b-purple">🏷️ ${esc(t.category)}</span>`:''}</div></div><div class="flex gap6"><button onclick="TasksPage.edit('${t.id}')" style="background:none;border:none;cursor:pointer;font-size:15px">✏️</button><button onclick="TasksPage.del('${t.id}')" style="background:none;border:none;cursor:pointer;font-size:15px">🗑️</button></div></div></div>`;
},
openAdd(){document.getElementById('tm-t').textContent='Yangi vazifa';document.getElementById('t-id').value='';['t-title','t-desc','t-due','t-cat'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''});document.getElementById('t-pri').value="o'rta";openModal('task-modal')},
edit(id){const t=(DB.get('tasks')||[]).find(t=>t.id===id);if(!t)return;document.getElementById('tm-t').textContent='Tahrirlash';document.getElementById('t-id').value=id;document.getElementById('t-title').value=t.title;document.getElementById('t-desc').value=t.desc||'';document.getElementById('t-pri').value=t.priority||"o'rta";document.getElementById('t-due').value=t.dueDate?new Date(t.dueDate).toISOString().split('T')[0]:'';document.getElementById('t-cat').value=t.category||'';openModal('task-modal')},
save(){const title=document.getElementById('t-title').value.trim();if(!title)return showToast('Sarlavha kiriting!','error');const editId=document.getElementById('t-id').value;const data={title,desc:document.getElementById('t-desc').value.trim(),priority:document.getElementById('t-pri').value,dueDate:document.getElementById('t-due').value?new Date(document.getElementById('t-due').value).getTime():null,category:document.getElementById('t-cat').value.trim()};if(editId)DB.update('tasks',editId,data);else DB.push('tasks',{...data,id:uid(),done:false,createdAt:Date.now()});closeModal('task-modal');showToast(editId?'Yangilandi ✅':'Qo\'shildi ✅','success');Sound.play('task');this.render()},
toggle(id){const t=(DB.get('tasks')||[]).find(t=>t.id===id);if(!t)return;DB.update('tasks',id,{done:!t.done,doneAt:!t.done?Date.now():null});if(!t.done){DB.set('analytics.tasks_done',(DB.get('analytics.tasks_done')||0)+1);showToast('Bajarildi! 🎉','success');Sound.play('success');vibrate([10,5,10]);}this.render()},
async del(id){if(await confirm2('Bu vazifani o\'chirish?')){DB.remove('tasks',id);this.render()}}
};

const FinancePage={filter:'all',render(){
  const fin=DB.get('finance')||{balance:0,currency:'UZS',transactions:[],categories:[]};
  const txs=fin.transactions||[];const now=new Date();
  const tm=txs.filter(t=>{const d=new Date(t.date);return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear()});
  const income=tm.filter(t=>t.type==='kirim').reduce((s,t)=>s+t.amount,0);
  const expense=tm.filter(t=>t.type==='chiqim').reduce((s,t)=>s+t.amount,0);
  const filtered=this.filter==='all'?txs:txs.filter(t=>t.type===this.filter);
  const sorted=[...filtered].sort((a,b)=>b.date-a.date).slice(0,30);
  const catExp={};tm.filter(t=>t.type==='chiqim').forEach(t=>{catExp[t.category||'Boshqa']=(catExp[t.category||'Boshqa']||0)+t.amount});
  document.getElementById('page-finance').innerHTML=`
    <div class="ph"><div class="flex ac jb"><h1>💰 Moliya</h1><div class="flex gap8"><button class="btn btn-s" style="padding:7px 11px;font-size:12px" onclick="DB.exportCSV('finance')">📥</button><button class="btn btn-p" style="padding:9px 14px;font-size:14px" onclick="FinancePage.openAdd()">+ Qo'shish</button></div></div></div>
    <div class="px">
      <div style="background:linear-gradient(135deg,rgba(10,132,255,.18),rgba(48,209,88,.13));border:1px solid rgba(10,132,255,.2);border-radius:var(--r4);padding:22px;margin-bottom:14px;text-align:center">
        <div style="font-size:13px;color:var(--t2);font-weight:500;margin-bottom:5px">Joriy balans</div>
        <div style="font-size:30px;font-weight:800;letter-spacing:-1px;color:${fin.balance>=0?'var(--green)':'var(--red)'}">${fmtMoney(fin.balance,fin.currency)}</div>
        <div style="font-size:12px;color:var(--t2);margin-top:7px">+${fmtMoney(income,fin.currency)} / -${fmtMoney(expense,fin.currency)}</div>
      </div>
      <div class="g2 mb14">
        <div class="sc"><div style="font-size:20px">📈</div><div class="sv tc-green" style="font-size:19px">${Number(income).toLocaleString('uz')}</div><div class="slb">Kirim (so'm)</div></div>
        <div class="sc"><div style="font-size:20px">📉</div><div class="sv tc-red" style="font-size:19px">${Number(expense).toLocaleString('uz')}</div><div class="slb">Chiqim (so'm)</div></div>
      </div>
      ${Object.keys(catExp).length>0?`<div class="sl">Kategoriyalar</div><div class="lg mb14">${Object.entries(catExp).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([cat,amt])=>{const pct=expense>0?Math.round((amt/expense)*100):0;return`<div class="li"><div class="li-ic" style="background:rgba(255,69,58,.14)">💸</div><div class="li-c"><div class="li-t">${esc(cat)}</div><div class="pb mt8"><div class="pf" style="width:${pct}%;background:var(--red)"></div></div></div><div style="text-align:right"><div style="font-size:13px;font-weight:700;color:var(--red)">${Number(amt).toLocaleString('uz')}</div><div style="font-size:10px;color:var(--t3)">${pct}%</div></div></div>`;}).join('')}</div>`:''}
      <div class="flex ac jb mb12"><div class="sl" style="margin-bottom:0">Tranzaksiyalar</div><div class="flex gap6">${['all','kirim','chiqim'].map(f=>`<div class="chip ${this.filter===f?'on':''}" style="padding:4px 9px;font-size:11px" onclick="FinancePage.filter='${f}';FinancePage.render()">${f==='all'?'Barchasi':f==='kirim'?'Kirim':'Chiqim'}</div>`).join('')}</div></div>
      ${sorted.length===0?`<div class="es"><div class="es-ic">💸</div><h3>Tranzaksiya yo'q</h3></div>`:`<div class="lg mb14">${sorted.map(t=>`<div class="li"><div class="li-ic" style="background:${t.type==='kirim'?'rgba(48,209,88,.14)':'rgba(255,69,58,.14)'}">${t.type==='kirim'?'💰':'💸'}</div><div class="li-c"><div class="li-t">${esc(t.title)}</div><div class="li-s">${esc(t.category||'Umumiy')} • ${fmt(t.date)}</div></div><div style="text-align:right"><div style="font-size:13px;font-weight:700;color:${t.type==='kirim'?'var(--green)':'var(--red)'}">${t.type==='kirim'?'+':'-'}${Number(t.amount).toLocaleString('uz')}</div><button onclick="FinancePage.del('${t.id}')" style="background:none;border:none;cursor:pointer;font-size:12px;color:var(--t3)">🗑️</button></div></div>`).join('')}</div>`}
      <div style="height:16px"></div>
    </div>
    <div class="mo" id="fin-modal"><div class="modal"><div class="mh"></div><h2>Tranzaksiya</h2>
    <div class="flex gap8 mb16"><button id="fin-k" class="btn btn-g f1" onclick="FinancePage._type('kirim')">📈 Kirim</button><button id="fin-c" class="btn btn-d f1" onclick="FinancePage._type('chiqim')">📉 Chiqim</button></div>
    <input type="hidden" id="fin-t" value="chiqim">
    <div class="fg"><label class="fl">Sarlavha *</label><input id="fin-title" placeholder="Nima uchun?"></div>
    <div class="fg"><label class="fl">Miqdor *</label><input id="fin-amt" type="number" placeholder="0"></div>
    <div class="g2"><div class="fg"><label class="fl">Kategoriya</label><select id="fin-cat">${(DB.get('finance.categories')||[]).map(c=>`<option>${c}</option>`).join('')}</select></div><div class="fg"><label class="fl">Sana</label><input id="fin-date" type="date" value="${new Date().toISOString().split('T')[0]}"></div></div>
    <div style="display:flex;gap:9px;margin-top:6px"><button class="btn btn-s f1" onclick="closeModal('fin-modal')">Bekor</button><button class="btn btn-p f1" onclick="FinancePage.save()">Saqlash</button></div>
    </div></div>
    <button class="fab" onclick="FinancePage.openAdd()"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`;
},
_type(t){document.getElementById('fin-t').value=t;document.getElementById('fin-k').style.opacity=t==='kirim'?1:.45;document.getElementById('fin-c').style.opacity=t==='chiqim'?1:.45},
openAdd(){openModal('fin-modal');setTimeout(()=>this._type('chiqim'),40)},
save(){const title=document.getElementById('fin-title').value.trim();const amt=parseFloat(document.getElementById('fin-amt').value);const type=document.getElementById('fin-t').value;if(!title||!amt||isNaN(amt))return showToast('Sarlavha va miqdor kiriting!','error');const tx={id:uid(),title,amount:amt,type,category:document.getElementById('fin-cat').value,date:new Date(document.getElementById('fin-date').value).getTime()};DB.push('finance.transactions',tx);const cur=DB.get('finance.balance')||0;DB.set('finance.balance',type==='kirim'?cur+amt:cur-amt);closeModal('fin-modal');showToast('Saqlandi ✅','success');this.render()},
async del(id){const txs=DB.get('finance.transactions')||[];const t=txs.find(t=>t.id===id);if(!t)return;if(await confirm2('O\'chirish?')){DB.remove('finance.transactions',id);const cur=DB.get('finance.balance')||0;DB.set('finance.balance',t.type==='kirim'?cur-t.amount:cur+t.amount);this.render();}}
};

const HealthPage={render(){
  const health=DB.get('health')||{};const now=new Date();const today=now.toDateString();
  const todayWater=(health.water||[]).filter(w=>new Date(w.time).toDateString()===today).reduce((s,w)=>s+w.amount,0);
  const wPct=Math.min(Math.round((todayWater/2000)*100),100);
  const todaySleep=(health.sleep||[]).find(s=>new Date(s.date).toDateString()===today);
  const todaySteps=(health.steps||[]).find(s=>new Date(s.date).toDateString()===today);
  const todayMood=(health.mood||[]).find(m=>new Date(m.date).toDateString()===today);
  const moods=['😢','😕','😐','🙂','😊'];
  document.getElementById('page-health').innerHTML=`
    <div class="ph"><h1>💊 Sog'liq</h1><p>Bugungi holat</p></div>
    <div class="px">
      <div class="g2 mb14">
        <div class="sc"><div style="font-size:20px">⚖️</div><div class="sv">${health.weight||'--'}<span style="font-size:13px;font-weight:400"> kg</span></div><div class="slb">Vazn</div><button onclick="HealthPage.logWeight()" class="btn btn-s" style="padding:5px 10px;font-size:11px;margin-top:6px">Yangilash</button></div>
        <div class="sc"><div style="font-size:20px">📏</div><div class="sv">${health.height||'--'}<span style="font-size:13px;font-weight:400"> sm</span></div><div class="slb">Bo'y</div>${health.weight&&health.height?`<div style="font-size:11px;color:var(--t2);margin-top:5px">BMI: ${(health.weight/((health.height/100)**2)).toFixed(1)}</div>`:''}</div>
      </div>
      <div class="sl">💧 Suv</div>
      <div class="card mb14"><div class="flex ac jb mb12"><div><div style="font-size:22px;font-weight:800">${todayWater}<span style="font-size:13px;color:var(--t2)"> / 2000ml</span></div></div><div style="position:relative;width:60px;height:60px"><svg width="60" height="60" viewBox="0 0 60 60"><circle cx="30" cy="30" r="24" fill="none" stroke="var(--glass)" stroke-width="5"/><circle cx="30" cy="30" r="24" fill="none" stroke="var(--teal)" stroke-width="5" stroke-linecap="round" stroke-dasharray="${2*Math.PI*24}" stroke-dashoffset="${2*Math.PI*24*(1-wPct/100)}" transform="rotate(-90 30 30)"/></svg><div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:16px">💧</div></div></div>
      <div class="flex gap7">${[150,200,250,350].map(ml=>`<button class="btn btn-s f1" style="padding:7px 3px;font-size:12px" onclick="HealthPage.addWater(${ml})">+${ml}</button>`).join('')}</div></div>
      <div class="sl">😴 Uyqu</div>
      <div class="card mb14"><div class="flex ac jb"><div><div style="font-size:22px;font-weight:800">${todaySleep?todaySleep.hours+' soat':'-- soat'}</div></div><button class="btn btn-p" style="padding:9px 14px;font-size:13px" onclick="HealthPage.logSleep()">Kiritish</button></div></div>
      <div class="sl">😊 Kayfiyat</div>
      <div class="card mb14"><div class="flex jc gap14">${moods.map((e,i)=>`<div onclick="HealthPage.logMood(${i+1})" style="cursor:pointer;text-align:center;transform:${todayMood?.value===i+1?'scale(1.3)':'scale(1)'};transition:transform .2s"><div style="font-size:28px;filter:${todayMood?.value===i+1?'none':'grayscale(.5)'}">${e}</div></div>`).join('')}</div></div>
      <div class="sl">👣 Qadamlar</div>
      <div class="card mb14"><div class="flex ac jb"><div><div style="font-size:22px;font-weight:800">${todaySteps?todaySteps.count.toLocaleString():'0'}</div><div style="font-size:12px;color:var(--t2)">/ 10,000</div></div><button class="btn btn-p" style="padding:9px 14px;font-size:13px" onclick="HealthPage.logSteps()">Kiritish</button></div>${todaySteps?`<div class="pb mt12"><div class="pf" style="width:${Math.min((todaySteps.count/10000)*100,100)}%;background:var(--orange)"></div></div>`:''}</div>
      <div style="height:16px"></div>
    </div>`;
},
addWater(ml){DB.push('health.water',{id:uid(),amount:ml,time:Date.now()});Sound.play('health');showToast(`+${ml}ml 💧`,'success');this.render()},
logSleep(){const h=prompt('Necha soat uxladingiz?');if(!h||isNaN(parseFloat(h)))return;const today=new Date().toDateString();const sleep=DB.get('health.sleep')||[];const idx=sleep.findIndex(s=>new Date(s.date).toDateString()===today);const entry={id:uid(),hours:parseFloat(h),date:Date.now()};if(idx>-1)sleep[idx]=entry;else sleep.push(entry);DB.set('health.sleep',sleep);showToast(`${h} soat 😴`,'success');this.render()},
logMood(v){const today=new Date().toDateString();const mood=DB.get('health.mood')||[];const idx=mood.findIndex(m=>new Date(m.date).toDateString()===today);const entry={id:uid(),value:v,date:Date.now()};if(idx>-1)mood[idx]=entry;else mood.push(entry);DB.set('health.mood',mood);this.render()},
logSteps(){const c=prompt('Bugun necha qadam?');if(!c||isNaN(parseInt(c)))return;const today=new Date().toDateString();const steps=DB.get('health.steps')||[];const idx=steps.findIndex(s=>new Date(s.date).toDateString()===today);const entry={id:uid(),count:parseInt(c),date:Date.now()};if(idx>-1)steps[idx]=entry;else steps.push(entry);DB.set('health.steps',steps);showToast(`${parseInt(c).toLocaleString()} qadam 👣`,'success');this.render()},
logWeight(){const w=prompt('Vazningiz (kg)?',DB.get('health.weight')||'');if(!w||isNaN(parseFloat(w)))return;DB.set('health.weight',parseFloat(w));showToast('Vazn yangilandi ⚖️','success');this.render()}
};

const FaceAuth={
  model:null,loading:false,
  async loadModel(){
    if(this.model)return true;
    if(this.loading)return false;
    this.loading=true;
    try{
      if(typeof faceapi==='undefined'){
        await this._loadScript('https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js');
      }
      const MODEL_URL='https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/weights';
      await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
        faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
        faceapi.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URL)
      ]);
      this.model=true;this.loading=false;return true;
    }catch(e){this.loading=false;console.error('Face model error',e);return false;}
  },
  _loadScript(src){return new Promise((res,rej)=>{const s=document.createElement('script');s.src=src;s.onload=res;s.onerror=rej;document.head.appendChild(s)})},
  async getDescriptor(video){
    const det=await faceapi.detectSingleFace(video,new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks(true).withFaceDescriptor();
    return det?det.descriptor:null;
  },
  euclidean(a,b){if(!a||!b)return999;let sum=0;for(let i=0;i<a.length;i++)sum+=(a[i]-b[i])**2;return Math.sqrt(sum)},
  async startCamera(videoEl){
    try{
      const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:320,height:240}});
      videoEl.srcObject=stream;await videoEl.play();return stream;
    }catch(e){return null}
  },
  stopCamera(stream){if(stream)stream.getTracks().forEach(t=>t.stop())},

  async register(){
    return new Promise(async(res)=>{
      const overlay=document.createElement('div');
      overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:9998;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:20px';
      overlay.innerHTML=`
        <div style="font-size:24px;font-weight:700;color:#fff;text-align:center">🎭 Yuz ro'yxatdan o'tkazish</div>
        <div style="font-size:14px;color:rgba(255,255,255,.6);text-align:center">Kameraga tik qarang</div>
        <div style="position:relative;width:280px;height:210px;border-radius:20px;overflow:hidden;border:2px solid var(--blue)">
          <video id="face-reg-video" style="width:100%;height:100%;object-fit:cover" playsinline muted autoplay></video>
          <div id="face-reg-overlay" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <div style="width:160px;height:200px;border:3px solid rgba(10,132,255,.7);border-radius:50%;box-shadow:0 0 0 2000px rgba(0,0,0,.3)"></div>
          </div>
        </div>
        <div id="face-reg-status" style="font-size:15px;color:rgba(255,255,255,.7);text-align:center">Model yuklanmoqda...</div>
        <button id="face-reg-btn" class="btn btn-p" style="padding:14px 32px;font-size:16px" disabled>📸 Rasmga olish</button>
        <button id="face-reg-cancel" class="btn btn-s" style="padding:10px 24px">Bekor qilish</button>`;
      document.body.appendChild(overlay);

      const video=overlay.querySelector('#face-reg-video');
      const status=overlay.querySelector('#face-reg-status');
      const btn=overlay.querySelector('#face-reg-btn');
      let stream=null;

      overlay.querySelector('#face-reg-cancel').onclick=()=>{this.stopCamera(stream);overlay.remove();res(false)};

      const ok=await this.loadModel();
      if(!ok){status.textContent='❌ Model yuklanmadi. Internet tekshiring';return;}
      stream=await this.startCamera(video);
      if(!stream){status.textContent='❌ Kamera ishlamadi';return;}
      status.textContent='Yuzingizni doira ichiga joylang';btn.disabled=false;

      btn.onclick=async()=>{
        btn.disabled=true;status.textContent='Aniqlanmoqda...';
        const descriptor=await this.getDescriptor(video);
        if(!descriptor){status.textContent='❌ Yuz topilmadi. Qayta urinib ko\'ring';btn.disabled=false;return;}
        this.stopCamera(stream);overlay.remove();
        DB.set('user.faceDescriptor',Array.from(descriptor));
        DB.set('user.faceRegistered',true);
        DB.set('settings.security.faceAuth',true);
        showToast('Yuz muvaffaqiyatli saqlandi! 🎭','success');
        res(true);
      };
    });
  },

  async verify(){
    return new Promise(async(res)=>{
      const saved=DB.get('user.faceDescriptor');
      if(!saved){res(true);return;}

      const overlay=document.createElement('div');
      overlay.style.cssText='position:fixed;inset:0;background:#000;z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:20px';
      overlay.innerHTML=`
        <div style="background:linear-gradient(135deg,#0A84FF,#BF5AF2);width:70px;height:70px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:32px;margin-bottom:4px">🤖</div>
        <div style="font-size:24px;font-weight:800;color:#fff">DILI AI</div>
        <div style="font-size:14px;color:rgba(255,255,255,.5);margin-bottom:8px">Yuzingizni skanerlang</div>
        <div style="position:relative;width:240px;height:280px;border-radius:50%;overflow:hidden;border:3px solid var(--blue);box-shadow:0 0 40px rgba(10,132,255,.4)">
          <video id="face-auth-video" style="width:100%;height:100%;object-fit:cover" playsinline muted autoplay></video>
        </div>
        <div id="face-auth-status" style="font-size:15px;color:rgba(255,255,255,.6)">Model yuklanmoqda...</div>
        <div id="face-auth-dots" style="display:flex;gap:8px;margin-top:4px">
          <div style="width:8px;height:8px;border-radius:50%;background:var(--blue);animation:pulse 1s infinite"></div>
          <div style="width:8px;height:8px;border-radius:50%;background:var(--blue);animation:pulse 1s infinite .2s"></div>
          <div style="width:8px;height:8px;border-radius:50%;background:var(--blue);animation:pulse 1s infinite .4s"></div>
        </div>
        <button id="face-pin-fallback" class="btn btn-s" style="margin-top:8px;font-size:13px">🔢 PIN bilan kirish</button>`;
      document.body.appendChild(overlay);

      const video=overlay.querySelector('#face-auth-video');
      const status=overlay.querySelector('#face-auth-status');
      let stream=null;let attempts=0;let scanning=false;

      overlay.querySelector('#face-pin-fallback').onclick=()=>{
        this.stopCamera(stream);overlay.remove();
        this._pinFallback(res);
      };

      const ok=await this.loadModel();
      if(!ok){status.textContent='❌ Offline rejim — PIN bilan kiring';this.stopCamera(stream);overlay.remove();this._pinFallback(res);return;}

      stream=await this.startCamera(video);
      if(!stream){status.textContent='❌ Kamera ishlamadi';overlay.remove();this._pinFallback(res);return;}
      status.textContent='Yuzingizni kameraga qarating...';

      const scan=async()=>{
        if(scanning)return;scanning=true;
        const descriptor=await this.getDescriptor(video);
        if(descriptor){
          const dist=this.euclidean(new Float32Array(saved),descriptor);
          if(dist<0.5){
            this.stopCamera(stream);overlay.remove();
            Sound.play('success');vibrate([50,30,50]);
            showToast('Yuz tasdiqlandi! ✅','success');
            res(true);return;
          }else{
            attempts++;
            if(attempts>=5){
              this.stopCamera(stream);overlay.remove();
              showToast('Yuz tanilmadi. PIN bilan kiring','error');
              this._pinFallback(res);return;
            }
            status.textContent=`❌ Yuz tanilmadi (${attempts}/5 urinish)`;
          }
        }
        scanning=false;
        setTimeout(scan,800);
      };
      setTimeout(scan,1500);
    });
  },

  _pinFallback(res){
    const overlay=document.createElement('div');
    overlay.style.cssText='position:fixed;inset:0;background:#000;z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:28px';
    let pin='';
    const render=()=>{
      overlay.innerHTML=`
        <div style="font-size:52px;margin-bottom:16px">🔐</div>
        <div style="font-size:20px;font-weight:700;color:#fff;margin-bottom:6px">PIN kiriting</div>
        <div style="font-size:13px;color:rgba(255,255,255,.5);margin-bottom:28px">6 raqamli PIN</div>
        <div style="display:flex;gap:10px;margin-bottom:28px">
          ${[0,1,2,3,4,5].map(i=>`<div style="width:14px;height:14px;border-radius:50%;background:${i<pin.length?'var(--blue)':'rgba(255,255,255,.2)'}"></div>`).join('')}
        </div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;max-width:260px">
          ${[1,2,3,4,5,6,7,8,9,'','0','⌫'].map(k=>`<button style="height:64px;font-size:22px;font-weight:600;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);border-radius:16px;color:#fff;cursor:pointer;font-family:var(--font)" onclick="window._pinPress('${k}')">${k}</button>`).join('')}
        </div>`;
    };
    window._pinPress=(key)=>{
      if(key==='')return;
      if(key==='⌫'){pin=pin.slice(0,-1);}
      else if(pin.length<6)pin+=key;
      render();
      if(pin.length===6){
        const saved=DB.get('settings.security.pin');
        if(pin===saved){overlay.remove();res(true);}
        else{pin='';render();Sound.play('error');vibrate([30,20,30]);showToast('Noto\'g\'ri PIN!','error');}
      }
    };
    document.body.appendChild(overlay);
    render();
  }
};

const DB={_d:null,
defaults(){return{
  user:{name:"G'iyosiddin Adhamjonov",language:"uz",theme:"dark",avatar:"👨‍💻",onboarded:false,faceRegistered:false,faceDescriptor:null},
  settings:{
    notifications:{tasks:true,finance:true,health:true,motivation:true,ramadan:true,sound:true,vibration:true,ringtone:'default'},
    voice:{enabled:false,wake_word:"DILI",tts_voice:"uz-UZ-MadinaNeural",stt_language:"uz-UZ"},
    gemini:{api_key:"",model:"gemini-2.5-flash",temperature:0.7},
    security:{pin:"",auto_lock:5,encrypt_data:true,faceAuth:true}
  },
  tasks:[],
  finance:{balance:0,currency:"UZS",transactions:[],categories:["Oziq-ovqat","Transport","Kiyim","Sog'liq","Ta'lim","Ko'ngilochar","Boshqa"]},
  health:{weight:null,height:null,sleep:[],water:[],steps:[],mood:[],medications:[]},
  vault:{items:[]},
  calendar:{events:[]},
  notes:[],goals:[],habits:[],
  ramadan:{fasting:[],prayers:[],location:"Toshkent",startDate:"2025-03-01",endDate:"2025-03-30"},
  nutrition:{meals:[],dailyGoal:{calories:2000,protein:60,carbs:250,fat:65}},
  pomodoro:{sessions:[],settings:{work:25,short:5,long:15,longAfter:4}},
  analytics:{ai_queries:0,tasks_done:0,login_streak:0,last_login:null,pomodoro_total:0},
  backup:{last:null}
}},
init(){
  try{const r=localStorage.getItem('dili_db_v3');this._d=r?JSON.parse(r):this.defaults();const df=this.defaults();for(const k in df)if(!(k in this._d))this._d[k]=df[k];}
  catch(e){this._d=this.defaults();}
  this._streak();return this;
},
save(){try{localStorage.setItem('dili_db_v3',JSON.stringify(this._d));}catch(e){}return this},
get(p){if(!p)return this._d;return p.split('.').reduce((o,k)=>o&&o[k]!==undefined?o[k]:null,this._d)},
set(p,v){const ks=p.split('.');let o=this._d;for(let i=0;i<ks.length-1;i++){if(!(ks[i] in o))o[ks[i]]={};o=o[ks[i]];}o[ks[ks.length-1]]=v;this.save();return this},
push(p,item){const a=this.get(p)||[];a.push(item);this.set(p,a);return item},
remove(p,id){const a=this.get(p)||[];this.set(p,a.filter(i=>i.id!==id))},
update(p,id,upd){const a=this.get(p)||[];const i=a.findIndex(x=>x.id===id);if(i>-1){a[i]={...a[i],...upd};this.set(p,a);}},
export(){const b=new Blob([JSON.stringify(this._d,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=`dili_v3_backup_${Date.now()}.json`;a.click()},
exportCSV(type){
  let csv='',data;
  if(type==='tasks'){data=this.get('tasks')||[];csv='ID,Sarlavha,Holat,Muhimlik,Muddat,Kategoriya\n';data.forEach(t=>csv+=`${t.id},"${(t.title||'').replace(/"/g,'""')}",${t.done?'Bajarildi':'Kutilmoqda'},${t.priority||''},${t.dueDate?new Date(t.dueDate).toLocaleDateString('uz'):''},"${(t.category||'').replace(/"/g,'""')}"\n`);}
  else if(type==='finance'){data=this.get('finance.transactions')||[];csv='ID,Sarlavha,Tur,Miqdor,Kategoriya,Sana\n';data.forEach(t=>csv+=`${t.id},"${(t.title||'').replace(/"/g,'""')}",${t.type},${t.amount},"${(t.category||'').replace(/"/g,'""')}",${new Date(t.date).toLocaleDateString('uz')}\n`);}
  else if(type==='nutrition'){data=this.get('nutrition.meals')||[];csv='ID,Nomi,Kaloriya,Oqsil,Uglevodlar,Yog,Sana\n';data.forEach(m=>csv+=`${m.id},"${(m.name||'').replace(/"/g,'""')}",${m.calories||0},${m.protein||0},${m.carbs||0},${m.fat||0},${new Date(m.date).toLocaleDateString('uz')}\n`);}
  else if(type==='pomodoro'){data=this.get('pomodoro.sessions')||[];csv='ID,Tur,Davomiyligi,Sana\n';data.forEach(s=>csv+=`${s.id},${s.type},${s.duration},${new Date(s.date).toLocaleDateString('uz')}\n`);}
  if(!csv)return showToast('Ma\'lumot yo\'q','error');
  const b=new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=`dili_${type}_${Date.now()}.csv`;a.click();showToast('CSV yuklandi ✅','success');
},
import(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=e=>{try{this._d=JSON.parse(e.target.result);this.save();res(true);}catch(err){rej(err);}};r.readAsText(file);})},
_streak(){const today=new Date().toDateString();const last=this._d.analytics.last_login;if(last!==today){const yest=new Date(Date.now()-86400000).toDateString();this._d.analytics.login_streak=last===yest?(this._d.analytics.login_streak||0)+1:1;this._d.analytics.last_login=today;this.save();}}
};

function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function fmt(d){if(!d)return'';const x=new Date(d);const m=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];return`${x.getDate()} ${m[x.getMonth()]}`}
function fmtFull(d){if(!d)return'';const x=new Date(d);const dy=['Yak','Dush','Sesh','Chor','Pay','Jum','Shan'];return`${dy[x.getDay()]}, ${x.getDate()}/${x.getMonth()+1}/${x.getFullYear()}`}
function fmtTime(d){const x=new Date(d);return`${String(x.getHours()).padStart(2,'0')}:${String(x.getMinutes()).padStart(2,'0')}`}
function fmtMoney(n,c='UZS'){if(c==='UZS')return Number(n||0).toLocaleString('uz')+' so\'m';return Number(n||0).toLocaleString()+' '+c}
function esc(s){if(!s)return'';const d=document.createElement('div');d.textContent=String(s);return d.innerHTML}
function secToMin(s){const m=Math.floor(s/60),sc=s%60;return`${String(m).padStart(2,'0')}:${String(sc).padStart(2,'0')}`}

let _tt;
function showToast(msg,type='default'){
  let t=document.getElementById('_toast');
  if(!t){t=document.createElement('div');t.id='_toast';t.className='toast';document.body.appendChild(t);}
  const ic={success:'✅',error:'❌',warning:'⚠️',default:'ℹ️'};
  t.innerHTML=`${ic[type]||ic.default} ${esc(msg)}`;t.classList.add('show');
  clearTimeout(_tt);_tt=setTimeout(()=>t.classList.remove('show'),3200);
}
function confirm2(msg){return new Promise(res=>{
  const o=document.createElement('div');o.className='mo show';
  o.innerHTML=`<div class="modal" style="padding:26px 20px 36px"><div class="mh"></div><h3 style="font-size:18px;font-weight:700;margin-bottom:10px">Tasdiqlash</h3><p style="color:var(--t2);font-size:14px;margin-bottom:22px">${esc(msg)}</p><div style="display:flex;gap:10px"><button class="btn btn-s f1" id="_cn">Bekor</button><button class="btn btn-d f1" id="_cy">Ha</button></div></div>`;
  document.body.appendChild(o);
  o.querySelector('#_cy').onclick=()=>{o.remove();res(true)};
  o.querySelector('#_cn').onclick=()=>{o.remove();res(false)};
})}
function vibrate(p=[10]){if(navigator.vibrate&&DB.get('settings.notifications.vibration'))navigator.vibrate(p)}
function applyTheme(t){document.documentElement.setAttribute('data-theme',t);const m=document.querySelector('meta[name="theme-color"]');if(m)m.content=t==='dark'?'#000000':'#f2f2f7'}
function openModal(id){const m=document.getElementById(id);if(m){m.classList.add('show');m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('show')},{once:true})}}
function closeModal(id){const m=document.getElementById(id);if(m)m.classList.remove('show')}

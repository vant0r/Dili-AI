const Nav={
  cur:'home',pages:['home','ai','tasks','finance','health','vault','calendar','notes','goals','habits','ramadan','nutrition','pomodoro','analytics','settings'],renderers:{},
  init(){
    document.querySelectorAll('.ni').forEach(b=>b.addEventListener('click',()=>{const p=b.dataset.page;if(p)this.go(p)}));
    document.querySelector('.naib')?.addEventListener('click',()=>this.go('ai'));
    document.getElementById('more-btn')?.addEventListener('click',()=>Drawer.open());
    const hash=location.hash.slice(1);this.go(this.pages.includes(hash)?hash:'home');
  },
  go(id){
    if(!this.pages.includes(id))id='home';
    document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
    document.querySelectorAll('.ni').forEach(b=>b.classList.remove('active'));
    const page=document.getElementById('page-'+id);if(page)page.classList.add('active');
    const btn=document.querySelector(`[data-page="${id}"]`);if(btn)btn.classList.add('active');
    const aib=document.querySelector('.naib');if(aib)aib.classList.toggle('active',id==='ai');
    this.cur=id;location.hash=id;Drawer.close();
    const r=this.renderers[id];if(r)r();
    vibrate([5]);window.scrollTo({top:0});
  },
  reg(id,fn){this.renderers[id]=fn}
};

const Drawer={
  open(){document.getElementById('drawer-ov').classList.add('show');document.getElementById('drawer').classList.add('show')},
  close(){document.getElementById('drawer-ov').classList.remove('show');document.getElementById('drawer').classList.remove('show')},
  init(){document.getElementById('drawer-ov')?.addEventListener('click',()=>this.close())}
};

const Onboarding={
  step:0,
  steps:[
    {emoji:'🤖',title:"DILI AI v3.0 ga xush kelibsiz!",desc:"G'iyosiddin, bu sizning kuchli shaxsiy yordamchingiz. Ramazon, pomodoro, kalori va ko'p narsani boshqaring!",btn:"Boshlash →"},
    {emoji:'🎭',title:"Yuz tekshiruvi",desc:"Xavfsizlik uchun yuzingizni ro'yxatdan o'tkazing. Faqat siz kira olasiz — boshqa hech kim!",btn:"Keyingisi →"},
    {emoji:'🌙',title:"Ramazon moduli",desc:"Ro'za kunlarini kuzating, namoz vaqtlarini belgilang. AI sizga ruhiy maslahat beradi.",btn:"Keyingisi →"},
    {emoji:'⚙️',title:"Gemini AI ulash",desc:"Barcha AI funksiyalar uchun Gemini API kalitini kiriting.",input:true,btn:"Boshlash 🚀"}
  ],
  show(){if(DB.get('user.onboarded'))return;const el=document.getElementById('onboarding');if(el){el.style.display='block';this.render();}},
  render(){
    const s=this.steps[this.step];const el=document.getElementById('onboarding');
    el.innerHTML=`<div style="position:fixed;inset:0;background:#000;z-index:10000;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px 28px">
      <div style="position:absolute;top:56px;left:50%;transform:translateX(-50%);display:flex;gap:8px">
        ${this.steps.map((_,i)=>`<div style="width:${i===this.step?24:8}px;height:8px;border-radius:4px;background:${i===this.step?'var(--blue)':'rgba(255,255,255,.15)'};transition:all .3s"></div>`).join('')}
      </div>
      <div style="font-size:76px;margin-bottom:24px;animation:scaleIn .4s cubic-bezier(.34,1.56,.64,1) both">${s.emoji}</div>
      <h2 style="font-size:24px;font-weight:800;text-align:center;letter-spacing:-.5px;margin-bottom:12px;color:#fff">${s.title}</h2>
      <p style="font-size:15px;color:rgba(255,255,255,.6);text-align:center;line-height:1.65;margin-bottom:28px">${s.desc}</p>
      ${s.input?`<div style="width:100%;max-width:340px;margin-bottom:18px"><div class="fl">Gemini API kaliti</div><input id="ob-key" type="password" placeholder="AIza..." value="${DB.get('settings.gemini.api_key')||''}"><div style="font-size:11px;color:rgba(255,255,255,.3);margin-top:6px">Keyinroq Sozlamalarda o'zgartirish mumkin</div></div>`:''}
      <button class="btn btn-p" style="width:100%;max-width:340px;padding:16px;font-size:16px;border-radius:var(--r3)" onclick="Onboarding.next()">${s.btn}</button>
      ${this.step>0?`<button onclick="Onboarding.skip()" style="background:none;border:none;color:rgba(255,255,255,.3);font-size:14px;margin-top:14px;cursor:pointer;font-family:var(--font)">O'tkazib yuborish</button>`:''}
    </div>`;
  },
  async next(){
    if(this.step===1){
      const reg=await FaceAuth.register();
      if(!reg)showToast("Yuz o'tkazilmadi, keyinroq sozlashingiz mumkin",'warning');
    }
    if(this.step===3){
      const key=document.getElementById('ob-key')?.value?.trim();
      if(key)DB.set('settings.gemini.api_key',key);
      this.done();
    }else{this.step++;this.render();}
  },
  skip(){this.done()},
  done(){DB.set('user.onboarded',true);document.getElementById('onboarding').innerHTML='';document.getElementById('onboarding').style.display='none';showToast('DILI AI v3.0 tayyor! 🤖','success');}
};

const HomePage={render(){
  const u=DB.get('user'),tasks=DB.get('tasks')||[],fin=DB.get('finance'),health=DB.get('health')||{};
  const habits=DB.get('habits')||[],goals=DB.get('goals')||[];
  const now=new Date(),h=now.getHours();
  const gr=h<6?"Yaxshi tun":h<12?"Xayrli tun, ":h<17?"Xayrli kun, ":h<21?"Xayrli kech, ":"Yaxshi tun, ";
  const pending=tasks.filter(t=>!t.done);
  const todayWater=(health.water||[]).filter(w=>new Date(w.time).toDateString()===now.toDateString()).reduce((s,w)=>s+w.amount,0);
  const streak=DB.get('analytics.login_streak')||1;
  const isRam=Notif._isRamadan();
  const todayFast=isRam?(DB.get('ramadan.fasting')||[]).find(f=>new Date(f.date).toDateString()===now.toDateString()):null;
  const pomSessions=(DB.get('pomodoro.sessions')||[]).filter(s=>new Date(s.date).toDateString()===now.toDateString()&&s.type==='work').length;
  const todayMeals=(DB.get('nutrition.meals')||[]).filter(m=>new Date(m.date).toDateString()===now.toDateString());
  const todayCal=todayMeals.reduce((s,m)=>s+m.calories,0);

  document.getElementById('page-home').innerHTML=`
    <div class="ph" style="background:transparent;position:relative;padding-top:54px">
      <div class="flex ac jb">
        <div>
          <div style="font-size:14px;color:var(--t2);font-weight:500;margin-bottom:3px">${gr}</div>
          <h1 style="font-size:25px;font-weight:800;letter-spacing:-.5px">${esc(u.name.split(' ')[0])} 👋</h1>
        </div>
        <div class="avatar" onclick="Nav.go('settings')" style="cursor:pointer">${u.avatar||'👨‍💻'}</div>
      </div>
      <div style="display:flex;gap:7px;overflow-x:auto;padding-bottom:2px;scrollbar-width:none;margin-top:14px">
        ${[['🤖','AI','ai'],['✅','Vazifa','tasks'],['💰','Moliya','finance'],['🌙','Ramazon','ramadan'],['⏱️','Pomodoro','pomodoro'],['🍽️','Kalori','nutrition']].map(([e,l,p])=>`<div class="chip" onclick="Nav.go('${p}')">${e} ${l}</div>`).join('')}
      </div>
    </div>
    <div class="px">
      ${isRam?`<div class="ramadan-card mb16">
        <div class="flex ac jb">
          <div class="flex ac gap12">
            <div style="font-size:32px">🌙</div>
            <div><div style="font-weight:700;font-size:16px;color:#4ade80">Ramazon Muborak!</div><div style="font-size:12px;color:rgba(74,222,128,.7)">${todayFast?.kept?'✅ Bugun ro\'za tutildi':'○ Ro\'za belgilanmagan'}</div></div>
          </div>
          <button class="btn btn-r" style="padding:7px 12px;font-size:12px" onclick="Nav.go('ramadan')">Ochish</button>
        </div>
      </div>`:''}
      <div style="background:linear-gradient(135deg,rgba(10,132,255,.14),rgba(191,90,242,.12));border:1px solid rgba(10,132,255,.22);border-radius:var(--r4);padding:18px;margin-bottom:14px;cursor:pointer" onclick="Nav.go('ai')">
        <div class="flex ac jb mb12">
          <div class="flex ac gap12">
            <div style="width:40px;height:40px;background:linear-gradient(135deg,var(--blue),var(--purple));border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:20px">🤖</div>
            <div><div style="font-weight:700;font-size:15px">DILI AI</div><div style="font-size:11px;color:var(--t2)">${DB.get('analytics.ai_queries')||0} so'rov • gemini-2.5-flash</div></div>
          </div>
          <div class="badge b-blue">● Faol</div>
        </div>
        <div style="font-size:13px;color:var(--t2)">Savol bering yoki hisobot so'rang 💬</div>
      </div>
      <div class="g2 mb14">
        <div class="sc" onclick="Nav.go('tasks')" style="cursor:pointer">
          <div style="font-size:20px">✅</div><div class="sv tc-blue">${pending.length}</div><div class="slb">Vazifalar</div>
        </div>
        <div class="sc" onclick="Nav.go('finance')" style="cursor:pointer">
          <div style="font-size:20px">💰</div><div class="sv" style="font-size:17px">${Number(fin?.balance||0).toLocaleString('uz')}</div><div class="slb">So'm</div>
        </div>
      </div>
      <div class="g2 mb14">
        <div class="sc" onclick="Nav.go('pomodoro')" style="cursor:pointer">
          <div style="font-size:20px">⏱️</div><div class="sv tc-orange">${pomSessions}</div><div class="slb">Pomodoro</div>
        </div>
        <div class="sc" onclick="Nav.go('nutrition')" style="cursor:pointer">
          <div style="font-size:20px">🍽️</div><div class="sv" style="font-size:20px">${todayCal}</div><div class="slb">kcal bugun</div>
        </div>
      </div>
      <div class="g2 mb14">
        <div class="sc">
          <div style="font-size:20px">💧</div><div class="sv tc-blue" style="font-size:20px">${todayWater}<span style="font-size:12px;color:var(--t2)">ml</span></div>
          <div class="slb">Suv</div><div class="pb mt8"><div class="pf" style="width:${Math.min((todayWater/2000)*100,100)}%;background:var(--teal)"></div></div>
        </div>
        <div class="sc"><div style="font-size:20px">🔥</div><div class="sv tc-orange">${streak}</div><div class="slb">Kun streak</div></div>
      </div>
      ${habits.length>0?`
        <div class="sl">Odatlar</div>
        <div style="display:flex;gap:10px;overflow-x:auto;padding-bottom:8px;margin-bottom:14px;scrollbar-width:none">
          ${habits.slice(0,6).map(hb=>{const done=(hb.completions||[]).some(c=>new Date(c).toDateString()===now.toDateString());
            return`<div style="flex-shrink:0;text-align:center;cursor:pointer" onclick="HabitsModule.toggle('${hb.id}')">
              <div style="width:52px;height:52px;border-radius:16px;background:${done?'rgba(48,209,88,.18)':'var(--glass)'};border:2px solid ${done?'var(--green)':'var(--border)'};display:flex;align-items:center;justify-content:center;font-size:22px;margin:0 auto 4px;transition:all .2s">${hb.emoji||'⭐'}</div>
              <div style="font-size:10px;font-weight:600;color:var(--t2);max-width:54px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(hb.name)}</div>
            </div>`;}).join('')}
        </div>`:''}
      ${pending.slice(0,3).length>0?`
        <div class="sl">Bugungi vazifalar</div>
        <div class="lg mb14">
          ${pending.slice(0,3).map(t=>`<div class="li" onclick="Nav.go('tasks')">
            <div style="width:21px;height:21px;border:2px solid var(--border2);border-radius:50%;flex-shrink:0"></div>
            <div class="li-c"><div class="li-t trunc">${esc(t.title)}</div>${t.dueDate?`<div class="li-s">${fmt(t.dueDate)}</div>`:''}</div>
            <div class="badge b-${t.priority==='yuqori'?'red':t.priority==="o'rta"?'orange':'blue'}">${t.priority||'oddiy'}</div>
          </div>`).join('')}
        </div>`:''}
      <div style="height:10px"></div>
    </div>`;
}};

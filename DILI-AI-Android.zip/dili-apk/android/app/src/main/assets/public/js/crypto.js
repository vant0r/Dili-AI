const Crypto={
  async encrypt(text,pass){
    const enc=new TextEncoder();const km=await crypto.subtle.importKey('raw',enc.encode(pass),'PBKDF2',false,['deriveKey']);
    const salt=crypto.getRandomValues(new Uint8Array(16));
    const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:100000,hash:'SHA-256'},km,{name:'AES-GCM',length:256},false,['encrypt']);
    const iv=crypto.getRandomValues(new Uint8Array(12));
    const e=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,enc.encode(text));
    const res=new Uint8Array(16+12+e.byteLength);res.set(salt,0);res.set(iv,16);res.set(new Uint8Array(e),28);
    return btoa(String.fromCharCode(...res));
  },
  async decrypt(cipher,pass){
    try{
      const data=Uint8Array.from(atob(cipher),c=>c.charCodeAt(0));
      const salt=data.slice(0,16);const iv=data.slice(16,28);const e=data.slice(28);
      const enc=new TextEncoder();const km=await crypto.subtle.importKey('raw',enc.encode(pass),'PBKDF2',false,['deriveKey']);
      const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:100000,hash:'SHA-256'},km,{name:'AES-GCM',length:256},false,['decrypt']);
      const dec=await crypto.subtle.decrypt({name:'AES-GCM',iv},key,e);
      return new TextDecoder().decode(dec);
    }catch(e){return null}
  }
};

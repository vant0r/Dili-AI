const PomodoroPage={
  timer:null,remaining:0,mode:'work',round:0,running:false,
  render(){
    const s=DB.get('pomodoro.settings')||{work:25,short:5,long:15,longAfter:4};
    const sessions=DB.get('pomodoro.sessions')||[];
    const today=new Date().toDateString();
    const todaySessions=sessions.filter(s=>new Date(s.date).toDateString()===today);
    const workSessions=todaySessions.filter(s=>s.type==='work').length;
    const totalMin=todaySessions.filter(s=>s.type==='work').reduce((sum,s)=>sum+s.duration,0);
    if(this.remaining===0)this.remaining=s.work*60;
    const el=document.getElementById('page-pomodoro');
    const circumference=2*Math.PI*54;
    const progress=this.remaining/(this[this.mode==='work'?'workSec':'mode'==='short'?'shortSec':'longSec']||s.work*60);
    const modeColors={work:'var(--red)',short:'var(--green)',long:'var(--blue)'};
    const modeNames={work:'🎯 Fokus',short:'☕ Qisqa dam',long:'🌿 Uzun dam'};
    el.innerHTML=`
      <div class="ph"><h1>⏱️ Pomodoro</h1><p>Fokus + Dam olish</p></div>
      <div class="px">
        <div class="g3 mb16">
          <div class="sc" style="text-align:center"><div style="font-size:20px">🎯</div><div class="sv" style="font-size:22px">${workSessions}</div><div class="slb">Bugun</div></div>
          <div class="sc" style="text-align:center"><div style="font-size:20px">⏰</div><div class="sv" style="font-size:22px">${totalMin}</div><div class="slb">Daqiqa</div></div>
          <div class="sc" style="text-align:center"><div style="font-size:20px">🔥</div><div class="sv" style="font-size:22px">${this.round}</div><div class="slb">Davra</div></div>
        </div>

        <div class="card mb16" style="text-align:center">
          <div style="font-size:15px;font-weight:600;color:${modeColors[this.mode]};margin-bottom:20px">${modeNames[this.mode]}</div>
          <div style="position:relative;width:160px;height:160px;margin:0 auto 20px">
            <svg width="160" height="160" viewBox="0 0 160 160">
              <circle cx="80" cy="80" r="54" fill="none" stroke="var(--glass)" stroke-width="10"/>
              <circle cx="80" cy="80" r="54" fill="none" stroke="${modeColors[this.mode]}" stroke-width="10"
                stroke-linecap="round" stroke-dasharray="${circumference}"
                id="pom-circle"
                stroke-dashoffset="${circumference*(1-(this.remaining/((this.mode==='work'?s.work:this.mode==='short'?s.short:s.long)*60)))}"
                transform="rotate(-90 80 80)" style="transition:stroke-dashoffset 1s linear"/>
            </svg>
            <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
              <div id="pom-time" style="font-size:36px;font-weight:800;letter-spacing:-1px">${secToMin(this.remaining)}</div>
              <div style="font-size:12px;color:var(--t2)">${this.mode==='work'?'Fokus vaqti':'Dam olish'}</div>
            </div>
          </div>
          <div class="flex jc gap12 mb16">
            <button class="btn btn-s" style="padding:8px 14px;font-size:13px" onclick="PomodoroPage.setMode('work',${s.work})">🎯 ${s.work}dk</button>
            <button class="btn btn-s" style="padding:8px 14px;font-size:13px" onclick="PomodoroPage.setMode('short',${s.short})">☕ ${s.short}dk</button>
            <button class="btn btn-s" style="padding:8px 14px;font-size:13px" onclick="PomodoroPage.setMode('long',${s.long})">🌿 ${s.long}dk</button>
          </div>
          <div class="flex jc gap12">
            <button class="btn ${this.running?'btn-d':'btn-p'}" style="padding:14px 32px;font-size:16px;border-radius:var(--r3)" onclick="PomodoroPage.toggle()">
              ${this.running?'⏸️ Pauza':'▶️ Boshlash'}
            </button>
            <button class="btn btn-s" style="padding:14px;border-radius:var(--r3)" onclick="PomodoroPage.reset()">↺</button>
          </div>
        </div>

        <div class="sl">Sozlamalar</div>
        <div class="card mb16">
          <div class="g2">
            <div class="fg"><label class="fl">Fokus (daqiqa)</label><input type="number" id="pom-work" value="${s.work}" min="1" max="60" onchange="PomodoroPage.saveSettings()"></div>
            <div class="fg"><label class="fl">Qisqa dam</label><input type="number" id="pom-short" value="${s.short}" min="1" max="30" onchange="PomodoroPage.saveSettings()"></div>
            <div class="fg"><label class="fl">Uzun dam</label><input type="number" id="pom-long" value="${s.long}" min="5" max="60" onchange="PomodoroPage.saveSettings()"></div>
            <div class="fg"><label class="fl">Uzun dam (necha davrada)</label><input type="number" id="pom-after" value="${s.longAfter}" min="2" max="8" onchange="PomodoroPage.saveSettings()"></div>
          </div>
        </div>

        ${todaySessions.length>0?`
        <div class="sl">Bugungi sessiyalar</div>
        <div class="lg mb16">
          ${todaySessions.slice(-5).reverse().map(s=>`<div class="li">
            <div class="li-ic" style="background:${s.type==='work'?'rgba(255,69,58,.14)':s.type==='short'?'rgba(48,209,88,.14)':'rgba(10,132,255,.14)'}">${s.type==='work'?'🎯':s.type==='short'?'☕':'🌿'}</div>
            <div class="li-c"><div class="li-t">${s.type==='work'?'Fokus sessiya':s.type==='short'?'Qisqa dam':'Uzun dam'}</div><div class="li-s">${s.duration} daqiqa • ${fmtTime(s.date)}</div></div>
          </div>`).join('')}
        </div>`:''}
        <div style="height:16px"></div>
      </div>`;
    if(this.running)this._startTick();
  },
  setMode(mode,min){
    this.stopTimer();this.mode=mode;this.remaining=min*60;this.running=false;this.render();
  },
  toggle(){
    if(this.running){this.stopTimer();this.running=false;}
    else{this.running=true;this._startTick();}
    const btn=document.querySelector('#page-pomodoro .btn-p, #page-pomodoro .btn-d');
    if(btn)btn.innerHTML=this.running?'⏸️ Pauza':'▶️ Boshlash';
    if(this.running)btn?.classList.replace('btn-p','btn-d');
    else btn?.classList.replace('btn-d','btn-p');
  },
  _startTick(){
    this.stopTimer();
    this.timer=setInterval(()=>{
      this.remaining--;
      const el=document.getElementById('pom-time');
      if(el)el.textContent=secToMin(this.remaining);
      const s=DB.get('pomodoro.settings')||{work:25,short:5,long:15};
      const total=(this.mode==='work'?s.work:this.mode==='short'?s.short:s.long)*60;
      const circ=2*Math.PI*54;
      const circle=document.getElementById('pom-circle');
      if(circle)circle.setAttribute('stroke-dashoffset',circ*(1-(this.remaining/total)));
      if(this.remaining<=0){
        this.stopTimer();this.running=false;
        Sound.play('pomodoro');vibrate([200,100,200,100,200]);
        const dur=this.mode==='work'?(s.work):this.mode==='short'?s.short:s.long;
        DB.push('pomodoro.sessions',{id:uid(),type:this.mode,duration:dur,date:Date.now()});
        if(this.mode==='work'){
          this.round++;DB.set('analytics.pomodoro_total',(DB.get('analytics.pomodoro_total')||0)+1);
          Notif.send('⏱️ Fokus tugadi!',`${dur} daqiqa fokus sessiya tugadi. Dam oling!`,'⏱️','pomodoro');
          const s2=DB.get('pomodoro.settings')||{longAfter:4};
          if(this.round%s2.longAfter===0){this.setMode('long',s2.long||15);}
          else{this.setMode('short',s2.short||5);}
        }else{
          Notif.send('☕ Dam tugadi!','Yana fokus vaqti boshlandi!','🎯','task');
          this.setMode('work',s.work||25);
        }
      }
    },1000);
  },
  stopTimer(){clearInterval(this.timer);this.timer=null},
  reset(){this.stopTimer();this.running=false;const s=DB.get('pomodoro.settings')||{work:25};this.remaining=s.work*60;this.mode='work';this.render()},
  saveSettings(){
    DB.set('pomodoro.settings',{
      work:parseInt(document.getElementById('pom-work')?.value)||25,
      short:parseInt(document.getElementById('pom-short')?.value)||5,
      long:parseInt(document.getElementById('pom-long')?.value)||15,
      longAfter:parseInt(document.getElementById('pom-after')?.value)||4
    });
    showToast('Sozlamalar saqlandi','success');
  }
};

const NutritionPage={
  render(){
    const meals=DB.get('nutrition.meals')||[];const goal=DB.get('nutrition.dailyGoal')||{calories:2000,protein:60,carbs:250,fat:65};
    const today=new Date().toDateString();const todayMeals=meals.filter(m=>new Date(m.date).toDateString()===today);
    const totals={calories:todayMeals.reduce((s,m)=>s+m.calories,0),protein:todayMeals.reduce((s,m)=>s+m.protein,0),carbs:todayMeals.reduce((s,m)=>s+m.carbs,0),fat:todayMeals.reduce((s,m)=>s+m.fat,0)};
    const calPct=Math.min(Math.round((totals.calories/goal.calories)*100),100);
    const el=document.getElementById('page-nutrition');
    el.innerHTML=`
      <div class="ph"><div class="flex ac jb"><h1>🍽️ Ovqatlanish</h1><div class="flex gap8"><button class="btn btn-s" style="padding:7px 11px;font-size:12px" onclick="DB.exportCSV('nutrition')">📥 CSV</button><button class="btn btn-p" style="padding:9px 14px;font-size:14px" onclick="NutritionPage.openAdd()">+ Qo'shish</button></div></div></div>
      <div class="px">
        <div class="card mb16">
          <div class="flex ac jb mb12">
            <div><div style="font-size:28px;font-weight:800">${totals.calories}<span style="font-size:15px;font-weight:400;color:var(--t2)"> / ${goal.calories} kcal</span></div><div style="font-size:13px;color:var(--t2)">${calPct}% kunlik maqsad</div></div>
            <div style="position:relative;width:72px;height:72px"><svg width="72" height="72" viewBox="0 0 72 72"><circle cx="36" cy="36" r="28" fill="none" stroke="var(--glass)" stroke-width="7"/><circle cx="36" cy="36" r="28" fill="none" stroke="var(--orange)" stroke-width="7" stroke-linecap="round" stroke-dasharray="${2*Math.PI*28}" stroke-dashoffset="${2*Math.PI*28*(1-calPct/100)}" transform="rotate(-90 36 36)"/></svg><div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:20px">🍽️</div></div>
          </div>
          <div class="g3" style="gap:8px">
            ${[['Oqsil','protein','blue'],['Uglevodlar','carbs','orange'],["Yog'",'fat','red']].map(([l,k,c])=>`<div style="text-align:center"><div style="font-size:14px;font-weight:700;color:var(--${c})">${totals[k]}g</div><div style="font-size:10px;color:var(--t2)">${l}</div><div style="font-size:10px;color:var(--t3)">/${goal[k]}g</div></div>`).join('')}
          </div>
        </div>

        <div class="sl">Bugungi ovqatlar</div>
        ${todayMeals.length===0?`<div class="es"><div class="es-ic">🍽️</div><h3>Ovqat qo'shilmagan</h3><p>Bugun nima yeginingizni kiriting</p></div>`:`<div class="lg mb16">${todayMeals.map(m=>`<div class="li"><div class="li-ic" style="background:rgba(255,159,10,.14)">🍽️</div><div class="li-c"><div class="li-t">${esc(m.name)}</div><div class="li-s">${m.calories} kcal • P:${m.protein}g K:${m.carbs}g Y:${m.fat}g</div></div><button onclick="NutritionPage.del('${m.id}')" style="background:none;border:none;cursor:pointer;font-size:14px;color:var(--t3)">🗑️</button></div>`).join('')}</div>`}

        <div class="sl mt16">Tez qo'shish</div>
        <div style="display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;margin-bottom:16px">
          ${[['🍚 Guruch','Guruch',250,5,55,1],['🍞 Non','Non',265,9,49,3],['🥚 Tuxum','Tuxum',78,6,0,5],['🥛 Sut','Sut',61,3,5,3],['🍗 Tovuq','Tovuq (100g)',165,31,0,4],['🥗 Salat','Salat',50,2,8,1]].map(([e,n,cal,p,c,f])=>`<div class="chip" onclick="NutritionPage.quickAdd('${n}',${cal},${p},${c},${f})">${e}</div>`).join('')}
        </div>

        <div style="height:16px"></div>
      </div>
      <div class="mo" id="nutr-modal"><div class="modal"><div class="mh"></div><h2>Ovqat qo'shish</h2>
        <div class="fg"><label class="fl">Ovqat nomi *</label><input id="n-name" placeholder="Nima yedingiz?"></div>
        <div class="g2">
          <div class="fg"><label class="fl">Kaloriya *</label><input id="n-cal" type="number" placeholder="0"></div>
          <div class="fg"><label class="fl">Oqsil (g)</label><input id="n-prot" type="number" placeholder="0"></div>
        </div>
        <div class="g2">
          <div class="fg"><label class="fl">Uglevodlar (g)</label><input id="n-carb" type="number" placeholder="0"></div>
          <div class="fg"><label class="fl">Yog' (g)</label><input id="n-fat" type="number" placeholder="0"></div>
        </div>
        <div class="fg"><label class="fl">Vaqt</label>
          <select id="n-meal"><option value="ertalik">🌅 Ertalik</option><option value="tushlik">☀️ Tushlik</option><option value="kechlik">🌙 Kechlik</option><option value="snack">🍎 Snack</option></select>
        </div>
        <div style="display:flex;gap:9px;margin-top:6px"><button class="btn btn-s f1" onclick="closeModal('nutr-modal')">Bekor</button><button class="btn btn-p f1" onclick="NutritionPage.save()">Saqlash</button></div>
      </div></div>
      <button class="fab" onclick="NutritionPage.openAdd()"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`;
  },
  openAdd(){['n-name','n-cal','n-prot','n-carb','n-fat'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''});openModal('nutr-modal')},
  quickAdd(name,cal,p,c,f){DB.push('nutrition.meals',{id:uid(),name,calories:cal,protein:p,carbs:c,fat:f,meal:'snack',date:Date.now()});showToast(`${name} qo'shildi 🍽️`,'success');this.render()},
  save(){const name=document.getElementById('n-name').value.trim();const cal=parseInt(document.getElementById('n-cal').value)||0;if(!name||!cal)return showToast('Nom va kaloriya kiriting!','error');DB.push('nutrition.meals',{id:uid(),name,calories:cal,protein:parseInt(document.getElementById('n-prot').value)||0,carbs:parseInt(document.getElementById('n-carb').value)||0,fat:parseInt(document.getElementById('n-fat').value)||0,meal:document.getElementById('n-meal').value,date:Date.now()});closeModal('nutr-modal');showToast('Ovqat saqlandi 🍽️','success');this.render()},
  async del(id){if(await confirm2('Bu ovqatni o\'chirish?')){DB.remove('nutrition.meals',id);this.render()}}
};

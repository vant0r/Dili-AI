const VaultPage={unlocked:false,pin:'',render(){
  const el=document.getElementById('page-vault');
  if(!this.unlocked){
    el.innerHTML=`<div class="ph"><h1>🔐 Maxfiy seyf</h1></div><div class="px"><div style="text-align:center;padding:36px 20px">
      <div style="font-size:60px;margin-bottom:18px">🔒</div>
      <div style="font-size:19px;font-weight:700;margin-bottom:7px">${DB.get('settings.security.pin')?'6 raqamli PIN':'Yangi PIN o\'rnating'}</div>
      <div id="pin-dots" style="display:flex;justify-content:center;gap:10px;margin-bottom:28px">${[0,1,2,3,4,5].map(i=>`<div id="dot-${i}" style="width:13px;height:13px;border-radius:50%;background:rgba(255,255,255,.2);transition:all .2s"></div>`).join('')}</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;max-width:256px;margin:0 auto">
        ${[1,2,3,4,5,6,7,8,9,'','0','⌫'].map(k=>`<button class="btn btn-s" style="height:62px;font-size:22px;font-weight:600;border-radius:var(--r2)" onclick="VaultPage.pinPress('${k}')">${k}</button>`).join('')}
      </div></div></div>`;this.pin='';
  }else{this._unlocked();}
},
pinPress(key){if(key==='')return;if(key==='⌫')this.pin=this.pin.slice(0,-1);else if(this.pin.length<6)this.pin+=key;
  for(let i=0;i<6;i++){const d=document.getElementById('dot-'+i);if(d)d.style.background=i<this.pin.length?'var(--blue)':'rgba(255,255,255,.2)';}
  if(this.pin.length===6){const saved=DB.get('settings.security.pin');if(!saved){DB.set('settings.security.pin',this.pin);this.unlocked=true;Sound.play('success');showToast('PIN o\'rnatildi! ✅','success');this.render();}else if(this.pin===saved){this.unlocked=true;Sound.play('success');vibrate([10,5,10]);this.render();}else{showToast('Noto\'g\'ri PIN! ❌','error');Sound.play('error');vibrate([30,20,30]);this.pin='';for(let i=0;i<6;i++){const d=document.getElementById('dot-'+i);if(d){d.style.background='var(--red)';setTimeout(()=>d.style.background='rgba(255,255,255,.2)',500);}}}}
},
_unlocked(){const items=DB.get('vault.items')||[];document.getElementById('page-vault').innerHTML=`
  <div class="ph"><div class="flex ac jb"><div><h1>🔓 Seyf</h1><p>${items.length} element</p></div><div class="flex gap8"><button class="btn btn-s" style="padding:7px 11px;font-size:12px" onclick="VaultPage.lock()">🔒</button><button class="btn btn-p" style="padding:9px 14px;font-size:13px" onclick="VaultPage.openAdd()">+ Qo'shish</button></div></div></div>
  <div class="px">${items.length===0?`<div class="es"><div class="es-ic">🔐</div><h3>Seyf bo'sh</h3><p>Parollar va maxfiy ma'lumotlar saqlang</p></div>`:`<div style="display:flex;flex-direction:column;gap:9px">${items.map(item=>`<div class="card flex ac gap12"><div class="li-ic" style="background:rgba(191,90,242,.14);font-size:20px">${{parol:'🔑',karta:'💳',eslatma:'📝',login:'👤',boshqa:'📋'}[item.type]||'🔐'}</div><div style="flex:1;min-width:0"><div style="font-size:15px;font-weight:600">${esc(item.title)}</div><div style="font-size:12px;color:var(--t2)">${esc(item.username||item.hint||'')}</div></div><div class="flex gap7"><button onclick="VaultPage.view('${item.id}')" class="btn btn-s" style="padding:6px 10px;font-size:12px">Ko'rish</button><button onclick="VaultPage.del('${item.id}')" style="background:none;border:none;cursor:pointer;font-size:15px">🗑️</button></div></div>`).join('')}</div>`}<div style="height:16px"></div></div>
  <div class="mo" id="vault-add"><div class="modal"><div class="mh"></div><h2>Yangi element</h2>
  <div class="fg"><label class="fl">Turi</label><select id="v-type"><option value="parol">🔑 Parol</option><option value="karta">💳 Karta</option><option value="login">👤 Login</option><option value="eslatma">📝 Eslatma</option><option value="boshqa">📋 Boshqa</option></select></div>
  <div class="fg"><label class="fl">Sarlavha *</label><input id="v-title" placeholder="Gmail parol..."></div>
  <div class="fg"><label class="fl">Foydalanuvchi nomi</label><input id="v-user" placeholder="login yoki email"></div>
  <div class="fg"><label class="fl">Maxfiy ma'lumot *</label><textarea id="v-secret" placeholder="Parol..." rows="3" style="resize:none"></textarea></div>
  <div class="fg"><label class="fl">Izoh</label><input id="v-hint" placeholder="Izoh..."></div>
  <div style="display:flex;gap:9px;margin-top:6px"><button class="btn btn-s f1" onclick="closeModal('vault-add')">Bekor</button><button class="btn btn-p f1" onclick="VaultPage.save()">🔐 Shifrlash</button></div>
  </div></div>
  <div class="mo" id="vault-view"><div class="modal"><div class="mh"></div><div id="vault-vc"></div><button class="btn btn-s btn-w mt16" onclick="closeModal('vault-view')">Yopish</button></div></div>
  <button class="fab" onclick="VaultPage.openAdd()"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`;
},
openAdd(){if(!this.unlocked)return;openModal('vault-add')},
async save(){const title=document.getElementById('v-title').value.trim();const secret=document.getElementById('v-secret').value.trim();if(!title||!secret)return showToast('Sarlavha va maxfiy ma\'lumot kiriting!','error');const pin=DB.get('settings.security.pin')||'000000';const encrypted=await Crypto.encrypt(secret,pin);DB.push('vault.items',{id:uid(),type:document.getElementById('v-type').value,title,username:document.getElementById('v-user').value.trim(),hint:document.getElementById('v-hint').value.trim(),encrypted,createdAt:Date.now()});closeModal('vault-add');Sound.play('success');showToast('Shifrlandi 🔐','success');this._unlocked()},
async view(id){const items=DB.get('vault.items')||[];const item=items.find(i=>i.id===id);if(!item)return;const pin=DB.get('settings.security.pin')||'000000';const dec=await Crypto.decrypt(item.encrypted,pin);document.getElementById('vault-vc').innerHTML=`<h2>${esc(item.title)}</h2>${item.username?`<div style="margin-top:11px"><div class="fl">Foydalanuvchi</div><div style="font-size:15px;margin-top:3px">${esc(item.username)}</div></div>`:''}<div style="margin-top:11px"><div class="fl">Maxfiy ma'lumot</div><div style="font-size:14px;margin-top:3px;background:var(--glass);padding:11px;border-radius:var(--r1);font-family:monospace;word-break:break-all">${dec?esc(dec):'❌ Shifr ochilmadi'}</div></div>${item.hint?`<div style="margin-top:11px"><div class="fl">Izoh</div><div style="font-size:13px;color:var(--t2)">${esc(item.hint)}</div></div>`:''}<button class="btn btn-s btn-w mt16" onclick="navigator.clipboard.writeText(${JSON.stringify(dec||'')});showToast('Nusxalandi!','success')">📋 Nusxalash</button>`;openModal('vault-view')},
async del(id){if(await confirm2('O\'chirish?')){DB.remove('vault.items',id);this._unlocked()}},
lock(){this.unlocked=false;this.pin='';this.render()}
};

const CalendarPage={cur:new Date(),render(){
  const events=DB.get('calendar.events')||[];const now=new Date();
  const y=this.cur.getFullYear(),m=this.cur.getMonth();
  const mn=['Yanvar','Fevral','Mart','Aprel','May','Iyun','Iyul','Avgust','Sentabr','Oktabr','Noyabr','Dekabr'];
  const dn=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
  const fd=new Date(y,m,1).getDay();const adj=fd===0?6:fd-1;const dim=new Date(y,m+1,0).getDate();
  const upcoming=[...events].filter(e=>new Date(e.date)>=now).sort((a,b)=>a.date-b.date).slice(0,5);
  let cal=`<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;text-align:center">${dn.map(d=>`<div style="font-size:11px;font-weight:700;color:var(--t2);padding:5px 0">${d}</div>`).join('')}`;
  let day=1;for(let i=0;i<42;i++){if(i<adj||day>dim){cal+='<div></div>';}else{const date=new Date(y,m,day);const isT=date.toDateString()===now.toDateString();const hasE=events.some(e=>new Date(e.date).toDateString()===date.toDateString());cal+=`<div onclick="CalendarPage.dayClick(${date.getTime()})" style="aspect-ratio:1;display:flex;flex-direction:column;align-items:center;justify-content:center;border-radius:50%;cursor:pointer;background:${isT?'var(--blue)':'transparent'};color:${isT?'#fff':'var(--t1)'};font-size:13px;font-weight:${isT?700:400};position:relative">${day}${hasE?`<div style="width:4px;height:4px;background:${isT?'#fff':'var(--blue)'};border-radius:50%;position:absolute;bottom:2px"></div>`:''}</div>`;day++;}}cal+='</div>';
  document.getElementById('page-calendar').innerHTML=`
    <div class="ph"><div class="flex ac jb"><h1>📅 Kalendar</h1><button class="btn btn-p" style="padding:9px 14px;font-size:14px" onclick="CalendarPage.openAdd()">+ Qo'shish</button></div></div>
    <div class="px"><div class="card mb14"><div class="flex ac jb mb14"><button class="btn btn-s" style="padding:7px 13px" onclick="CalendarPage.prev()">‹</button><div style="font-size:16px;font-weight:700">${mn[m]} ${y}</div><button class="btn btn-s" style="padding:7px 13px" onclick="CalendarPage.next()">›</button></div>${cal}</div>
    ${upcoming.length>0?`<div class="sl">Kelgusi</div><div class="lg mb14">${upcoming.map(e=>`<div class="li"><div class="li-ic" style="background:rgba(10,132,255,.14)">📅</div><div class="li-c"><div class="li-t">${esc(e.title)}</div><div class="li-s">${fmtFull(e.date)}${e.time?' • '+e.time:''}</div></div><button onclick="CalendarPage.del('${e.id}')" style="background:none;border:none;cursor:pointer;font-size:15px">🗑️</button></div>`).join('')}</div>`:''}
    <div style="height:16px"></div></div>
    <div class="mo" id="cal-modal"><div class="modal"><div class="mh"></div><h2>Yangi tadbir</h2>
    <div class="fg"><label class="fl">Sarlavha *</label><input id="cal-t" placeholder="Tadbir nomi"></div>
    <div class="fg"><label class="fl">Sana *</label><input id="cal-d" type="date"></div>
    <div class="fg"><label class="fl">Vaqt</label><input id="cal-tm" type="time"></div>
    <div style="display:flex;gap:9px;margin-top:6px"><button class="btn btn-s f1" onclick="closeModal('cal-modal')">Bekor</button><button class="btn btn-p f1" onclick="CalendarPage.save()">Saqlash</button></div>
    </div></div>`;
},
prev(){this.cur.setMonth(this.cur.getMonth()-1);this.render()},next(){this.cur.setMonth(this.cur.getMonth()+1);this.render()},
dayClick(ts){document.getElementById('cal-d').value=new Date(ts).toISOString().split('T')[0];openModal('cal-modal')},
openAdd(){document.getElementById('cal-d').value=new Date().toISOString().split('T')[0];openModal('cal-modal')},
save(){const t=document.getElementById('cal-t').value.trim();const d=document.getElementById('cal-d').value;if(!t||!d)return showToast('Sarlavha va sana kiriting!','error');DB.push('calendar.events',{id:uid(),title:t,date:new Date(d).getTime(),time:document.getElementById('cal-tm').value});closeModal('cal-modal');Sound.play('success');showToast('Qo\'shildi ✅','success');this.render()},
async del(id){if(await confirm2('O\'chirish?')){DB.remove('calendar.events',id);this.render()}}
};

const NotesPage={render(){
  const notes=DB.get('notes')||[];const sorted=[...notes].sort((a,b)=>b.updatedAt-a.updatedAt);
  document.getElementById('page-notes').innerHTML=`
    <div class="ph"><div class="flex ac jb"><h1>📝 Eslatmalar</h1><div class="flex gap8"><button class="btn btn-s" style="padding:7px 11px;font-size:12px" onclick="DB.exportCSV('notes')">📥</button><button class="btn btn-p" style="padding:9px 14px;font-size:14px" onclick="NotesPage.openAdd()">+ Yangi</button></div></div>
    <input id="ns" placeholder="🔍 Qidirish..." style="margin-top:12px" oninput="NotesPage.search(this.value)"></div>
    <div class="px">${notes.length===0?`<div class="es"><div class="es-ic">📝</div><h3>Eslatmalar yo'q</h3></div>`:`<div id="nl" style="display:grid;grid-template-columns:1fr 1fr;gap:9px">${sorted.map(n=>this._card(n)).join('')}</div>`}<div style="height:16px"></div></div>
    <div class="mo" id="notes-modal"><div class="modal"><div class="mh"></div><h2 id="nm-t">Yangi eslatma</h2>
    <input type="hidden" id="n-id"><div class="fg"><label class="fl">Sarlavha</label><input id="n-title" placeholder="Sarlavha..."></div>
    <div class="fg"><label class="fl">Matn *</label><textarea id="n-body" rows="6" style="resize:none" placeholder="Fikrlaringizni yozing..."></textarea></div>
    <div class="fg"><label class="fl">Rang</label><div class="flex gap8">${['#0A84FF','#30D158','#FF9F0A','#FF453A','#BF5AF2','#FF375F'].map(c=>`<div onclick="document.getElementById('n-color').value='${c}'" style="width:26px;height:26px;border-radius:50%;background:${c};cursor:pointer;flex-shrink:0"></div>`).join('')}</div><input type="hidden" id="n-color" value="#0A84FF"></div>
    <div style="display:flex;gap:9px;margin-top:6px"><button class="btn btn-s f1" onclick="closeModal('notes-modal')">Bekor</button><button class="btn btn-p f1" onclick="NotesPage.save()">Saqlash</button></div>
    </div></div>
    <button class="fab" onclick="NotesPage.openAdd()"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`;
},
_card(n){return`<div style="background:${n.color?n.color+'22':'var(--card)'};border:1px solid ${n.color||'var(--border)'};border-radius:var(--r3);padding:14px;cursor:pointer" onclick="NotesPage.edit('${n.id}')">${n.title?`<div style="font-size:13px;font-weight:700;margin-bottom:5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(n.title)}</div>`:''}<div style="font-size:12px;color:var(--t2);line-height:1.5;overflow:hidden;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical">${esc(n.body)}</div><div style="font-size:10px;color:var(--t3);margin-top:8px">${fmt(n.updatedAt)}</div></div>`},
openAdd(){document.getElementById('nm-t').textContent='Yangi eslatma';document.getElementById('n-id').value='';document.getElementById('n-title').value='';document.getElementById('n-body').value='';openModal('notes-modal')},
edit(id){const n=(DB.get('notes')||[]).find(n=>n.id===id);if(!n)return;document.getElementById('nm-t').textContent='Tahrirlash';document.getElementById('n-id').value=id;document.getElementById('n-title').value=n.title||'';document.getElementById('n-body').value=n.body||'';document.getElementById('n-color').value=n.color||'#0A84FF';openModal('notes-modal')},
save(){const body=document.getElementById('n-body').value.trim();if(!body)return showToast('Matn kiriting!','error');const editId=document.getElementById('n-id').value;const data={title:document.getElementById('n-title').value.trim(),body,color:document.getElementById('n-color').value,updatedAt:Date.now()};if(editId)DB.update('notes',editId,data);else DB.push('notes',{...data,id:uid(),createdAt:Date.now()});closeModal('notes-modal');showToast('Saqlandi 📝','success');this.render()},
search(q){const notes=DB.get('notes')||[];const f=q?notes.filter(n=>(n.title+n.body).toLowerCase().includes(q.toLowerCase())):notes;const c=document.getElementById('nl');if(c)c.innerHTML=f.map(n=>this._card(n)).join('')}
};

const GoalsPage={render(){
  const goals=DB.get('goals')||[];const active=goals.filter(g=>!g.completed);const done=goals.filter(g=>g.completed);
  document.getElementById('page-goals').innerHTML=`
    <div class="ph"><div class="flex ac jb"><div><h1>🎯 Maqsadlar</h1><p>${done.length} erishildi</p></div><button class="btn btn-p" style="padding:9px 14px;font-size:14px" onclick="GoalsPage.openAdd()">+ Qo'shish</button></div></div>
    <div class="px">${active.length===0?`<div class="es"><div class="es-ic">🎯</div><h3>Maqsadlar yo'q</h3></div>`:`<div style="display:flex;flex-direction:column;gap:11px">${active.map(g=>this._card(g)).join('')}</div>`}
    ${done.length>0?`<div class="sl mt16">✅ Erishilganlar</div><div style="display:flex;flex-direction:column;gap:9px">${done.map(g=>`<div class="card flex ac gap12" style="opacity:.55"><div style="font-size:26px">${g.emoji||'🎯'}</div><div><div style="font-size:14px;font-weight:600;text-decoration:line-through">${esc(g.title)}</div></div></div>`).join('')}</div>`:''}
    <div style="height:16px"></div></div>
    <div class="mo" id="goals-modal"><div class="modal"><div class="mh"></div><h2 id="gm-t">Yangi maqsad</h2><input type="hidden" id="g-id">
    <div class="g2"><div class="fg"><label class="fl">Emoji</label><input id="g-emoji" placeholder="🎯" style="font-size:22px;text-align:center"></div><div class="fg"><label class="fl">Sarlavha *</label><input id="g-title" placeholder="Maqsad nomi"></div></div>
    <div class="g2"><div class="fg"><label class="fl">Joriy</label><input id="g-cur" type="number" placeholder="0"></div><div class="fg"><label class="fl">Maqsad *</label><input id="g-tgt" type="number" placeholder="100"></div></div>
    <div class="g2"><div class="fg"><label class="fl">Birlik</label><input id="g-unit" placeholder="km, soat..."></div><div class="fg"><label class="fl">Muddat</label><input id="g-dl" type="date"></div></div>
    <div style="display:flex;gap:9px;margin-top:6px"><button class="btn btn-s f1" onclick="closeModal('goals-modal')">Bekor</button><button class="btn btn-p f1" onclick="GoalsPage.save()">Saqlash</button></div>
    </div></div>
    <button class="fab" onclick="GoalsPage.openAdd()"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`;
},
_card(g){const pct=g.target>0?Math.min(Math.round(((g.current||0)/g.target)*100),100):0;const dl=g.deadline?Math.ceil((new Date(g.deadline)-new Date())/86400000):null;
  return`<div class="card"><div class="flex ac jb mb12"><div class="flex ac gap12"><div style="font-size:30px">${g.emoji||'🎯'}</div><div><div style="font-size:15px;font-weight:700">${esc(g.title)}</div></div></div><div class="flex gap5"><button onclick="GoalsPage.edit('${g.id}')" style="background:none;border:none;cursor:pointer;font-size:15px">✏️</button><button onclick="GoalsPage.del('${g.id}')" style="background:none;border:none;cursor:pointer;font-size:15px">🗑️</button></div></div>
  <div class="flex ac jb mb7"><div style="font-size:12px;color:var(--t2)">${g.current||0}/${g.target||0} ${g.unit||''}</div><div style="font-size:14px;font-weight:700;color:${pct===100?'var(--green)':'var(--blue)'}">${pct}%</div></div>
  <div class="pb mb12"><div class="pf" style="width:${pct}%;background:${pct===100?'var(--green)':'var(--blue)'}"></div></div>
  <div class="flex ac jb"><div class="flex gap6"><button class="btn btn-s" style="padding:5px 10px;font-size:12px" onclick="GoalsPage.upd('${g.id}',-1)">- Kamaytir</button><button class="btn btn-p" style="padding:5px 10px;font-size:12px" onclick="GoalsPage.upd('${g.id}',1)">+ Oshir</button></div>${dl!==null?`<div style="font-size:11px;color:${dl<7?'var(--red)':'var(--t2)'}">${dl>0?dl+' kun':'Muddat o\'tdi'}</div>`:''}</div></div>`;
},
openAdd(){document.getElementById('gm-t').textContent='Yangi maqsad';document.getElementById('g-id').value='';['g-emoji','g-title','g-cur','g-tgt','g-unit','g-dl'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''});openModal('goals-modal')},
edit(id){const g=(DB.get('goals')||[]).find(g=>g.id===id);if(!g)return;document.getElementById('gm-t').textContent='Tahrirlash';document.getElementById('g-id').value=id;document.getElementById('g-emoji').value=g.emoji||'';document.getElementById('g-title').value=g.title;document.getElementById('g-cur').value=g.current||0;document.getElementById('g-tgt').value=g.target||'';document.getElementById('g-unit').value=g.unit||'';document.getElementById('g-dl').value=g.deadline?new Date(g.deadline).toISOString().split('T')[0]:'';openModal('goals-modal')},
save(){const title=document.getElementById('g-title').value.trim();if(!title)return showToast('Sarlavha kiriting!','error');const editId=document.getElementById('g-id').value;const data={emoji:document.getElementById('g-emoji').value||'🎯',title,current:parseFloat(document.getElementById('g-cur').value)||0,target:parseFloat(document.getElementById('g-tgt').value)||100,unit:document.getElementById('g-unit').value.trim(),deadline:document.getElementById('g-dl').value?new Date(document.getElementById('g-dl').value).getTime():null};if(editId)DB.update('goals',editId,data);else DB.push('goals',{...data,id:uid(),completed:false,createdAt:Date.now()});closeModal('goals-modal');showToast('Saqlandi 🎯','success');this.render()},
upd(id,dir){const amt=parseFloat(prompt(`Qiymat?`)||0);if(isNaN(amt)||amt<=0)return;const goals=DB.get('goals')||[];const g=goals.find(g=>g.id===id);if(!g)return;const nv=Math.max(0,(g.current||0)+(dir*amt));const completed=g.target>0&&nv>=g.target;DB.update('goals',id,{current:nv,completed});if(completed){showToast('Maqsadga erishdingiz! 🎉','success');Sound.play('success');vibrate([20,10,20,10,20]);}this.render()},
async del(id){if(await confirm2('O\'chirish?')){DB.remove('goals',id);this.render()}}
};

const HabitsPage={render(){
  const habits=DB.get('habits')||[];const now=new Date();const today=now.toDateString();
  document.getElementById('page-habits').innerHTML=`
    <div class="ph"><div class="flex ac jb"><div><h1>⭐ Odatlar</h1></div><button class="btn btn-p" style="padding:9px 14px;font-size:14px" onclick="HabitsPage.openAdd()">+ Qo'shish</button></div></div>
    <div class="px">${habits.length===0?`<div class="es"><div class="es-ic">⭐</div><h3>Odatlar yo'q</h3></div>`:habits.map(h=>{
      const comps=h.completions||[];const done=comps.some(c=>new Date(c).toDateString()===today);
      let streak=0;let check=new Date();for(const c of [...comps].sort((a,b)=>b-a)){const d=new Date(c);if(d.toDateString()===check.toDateString()){streak++;check.setDate(check.getDate()-1);}else break;}
      const last7=Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(6-i));return comps.some(c=>new Date(c).toDateString()===d.toDateString())});
      return`<div class="card mb12"><div class="flex ac jb mb12"><div class="flex ac gap12"><div style="font-size:28px">${h.emoji||'⭐'}</div><div><div style="font-size:15px;font-weight:700">${esc(h.name)}</div><div style="font-size:11px;color:var(--t2)">🔥 ${streak} kun</div></div></div><div onclick="HabitsModule.toggle('${h.id}')" style="width:38px;height:38px;border-radius:50%;background:${done?'rgba(48,209,88,.18)':'var(--glass)'};border:2px solid ${done?'var(--green)':'var(--border)'};display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:16px;transition:all .2s">${done?'✅':'○'}</div></div><div class="flex gap3">${last7.map(d=>`<div style="flex:1;height:5px;border-radius:2px;background:${d?'var(--green)':'var(--glass)'}"></div>`).join('')}</div></div>`;
    }).join('')}
    <div style="height:16px"></div></div>
    <div class="mo" id="habits-modal"><div class="modal"><div class="mh"></div><h2>Yangi odat</h2>
    <div class="g2"><div class="fg"><label class="fl">Emoji</label><input id="h-emoji" placeholder="⭐" style="font-size:22px;text-align:center"></div><div class="fg"><label class="fl">Odat nomi *</label><input id="h-name" placeholder="Kitob o'qish..."></div></div>
    <div style="display:flex;gap:9px;margin-top:6px"><button class="btn btn-s f1" onclick="closeModal('habits-modal')">Bekor</button><button class="btn btn-p f1" onclick="HabitsPage.save()">Saqlash</button></div>
    </div></div>
    <button class="fab" onclick="HabitsPage.openAdd()"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`;
},
openAdd(){openModal('habits-modal')},
save(){const name=document.getElementById('h-name').value.trim();if(!name)return showToast('Odat nomini kiriting!','error');DB.push('habits',{id:uid(),name,emoji:document.getElementById('h-emoji').value||'⭐',completions:[],createdAt:Date.now()});closeModal('habits-modal');showToast('Odat qo\'shildi ⭐','success');if(Nav.cur==='home')HomePage.render();this.render()}
};

const HabitsModule={toggle(id){
  const today=new Date().toDateString();const habits=DB.get('habits')||[];const h=habits.find(h=>h.id===id);if(!h)return;
  const comps=h.completions||[];const done=comps.some(c=>new Date(c).toDateString()===today);
  if(done)DB.update('habits',id,{completions:comps.filter(c=>new Date(c).toDateString()!==today)});
  else{DB.update('habits',id,{completions:[...comps,Date.now()]});Sound.play('success');vibrate([10]);showToast(`${h.emoji||'⭐'} ${h.name} ✅`,'success');}
  if(Nav.cur==='home')HomePage.render();else if(Nav.cur==='habits')HabitsPage.render();
}};

const AnalyticsPage={render(){
  const an=DB.get('analytics')||{};const tasks=DB.get('tasks')||[];const fin=DB.get('finance')||{};const goals=DB.get('goals')||[];const habits=DB.get('habits')||[];const notes=DB.get('notes')||[];
  const done=tasks.filter(t=>t.done).length;const total=tasks.length;const pct=total>0?Math.round((done/total)*100):0;
  const now=new Date();const txs=fin.transactions||[];
  const tm=txs.filter(t=>{const d=new Date(t.date);return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear()});
  const income=tm.filter(t=>t.type==='kirim').reduce((s,t)=>s+t.amount,0);const expense=tm.filter(t=>t.type==='chiqim').reduce((s,t)=>s+t.amount,0);
  const last7=Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(6-i));const ds=d.toDateString();const cnt=tasks.filter(t=>t.doneAt&&new Date(t.doneAt).toDateString()===ds).length;return{day:['Ya','Du','Se','Ch','Pa','Ju','Sh'][d.getDay()],count:cnt}});
  const mx=Math.max(...last7.map(d=>d.count),1);
  const pomTotal=DB.get('analytics.pomodoro_total')||0;
  const ramFasting=(DB.get('ramadan.fasting')||[]).filter(f=>f.kept).length;

  document.getElementById('page-analytics').innerHTML=`
    <div class="ph"><div class="flex ac jb"><h1>📊 Analitika</h1><button class="btn btn-s" style="padding:7px 11px;font-size:12px" onclick="AnalyticsPage.getAIReport()">🤖 AI Xulosa</button></div></div>
    <div class="px">
      <div class="g2 mb14">
        <div class="sc"><div style="font-size:20px">🤖</div><div class="sv tc-blue">${an.ai_queries||0}</div><div class="slb">AI so'rovlar</div></div>
        <div class="sc"><div style="font-size:20px">🔥</div><div class="sv tc-orange">${an.login_streak||1}</div><div class="slb">Streak</div></div>
      </div>
      <div class="g2 mb14">
        <div class="sc"><div style="font-size:20px">✅</div><div class="sv tc-green">${done}</div><div class="slb">Bajarildi</div><div class="sch up">${pct}%</div></div>
        <div class="sc"><div style="font-size:20px">⏱️</div><div class="sv tc-orange">${pomTotal}</div><div class="slb">Pomodoro</div></div>
      </div>
      <div class="g2 mb14">
        <div class="sc"><div style="font-size:20px">🌙</div><div class="sv tc-green">${ramFasting}</div><div class="slb">Ro'za kunlar</div></div>
        <div class="sc"><div style="font-size:20px">🎯</div><div class="sv" style="color:var(--purple)">${goals.filter(g=>g.completed).length}</div><div class="slb">Maqsadlar</div></div>
      </div>
      <div class="sl">So'ngi 7 kun</div>
      <div class="card mb14"><div style="display:flex;align-items:flex-end;gap:7px;height:72px">${last7.map(d=>`<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px"><div style="background:var(--blue);border-radius:3px 3px 0 0;width:100%;height:${Math.max((d.count/mx)*62,3)}px;opacity:${d.count>0?1:.22}"></div><div style="font-size:9px;color:var(--t2)">${d.day}</div></div>`).join('')}</div></div>
      <div class="sl">Bu oylik moliya</div>
      <div class="card mb14"><div class="flex jb"><div><div style="font-size:11px;color:var(--t2)">Kirim</div><div style="font-size:17px;font-weight:700;color:var(--green)">${Number(income).toLocaleString('uz')}</div></div><div style="text-align:right"><div style="font-size:11px;color:var(--t2)">Chiqim</div><div style="font-size:17px;font-weight:700;color:var(--red)">${Number(expense).toLocaleString('uz')}</div></div></div>${income+expense>0?`<div class="pb mt12"><div class="pf" style="width:${Math.round((income/(income+expense))*100)}%;background:var(--green)"></div></div>`:''}</div>
      <div id="ai-report-area" style="display:none" class="card mb14"><div id="ai-report-text" style="font-size:14px;line-height:1.6;color:var(--t2)"></div></div>
      <div style="height:16px"></div>
    </div>`;
},
async getAIReport(){
  const area=document.getElementById('ai-report-area');const text=document.getElementById('ai-report-text');
  if(area){area.style.display='block';if(text)text.textContent='AI xulosa tayyorlanmoqda...'}
  const r=await AI.generateReport('weekly');
  if(text&&r)text.textContent=r;
}
};

const SettingsPage={render(){
  const s=DB.get('settings')||{};const u=DB.get('user')||{};const n=s.notifications||{};const v=s.voice||{};const g=s.gemini||{};const sec=s.security||{};
  document.getElementById('page-settings').innerHTML=`
    <div class="ph"><h1>⚙️ Sozlamalar</h1></div>
    <div class="px">
      <div class="sl">Foydalanuvchi</div>
      <div class="lg mb14">
        <div class="li"><div class="avatar">${u.avatar||'👨‍💻'}</div><div class="li-c"><div class="li-t">${esc(u.name||'')}</div><div class="li-s">Profilni tahrirlash</div></div><button class="btn btn-s" style="padding:6px 11px;font-size:12px" onclick="SettingsPage.editProfile()">Tahrirlash</button></div>
        <div class="li"><div class="li-ic" style="background:rgba(10,132,255,.14)">🎨</div><div class="li-c"><div class="li-t">Mavzu</div></div><div class="flex gap7"><button class="btn ${u.theme==='dark'?'btn-p':'btn-s'}" style="padding:5px 10px;font-size:12px" onclick="SettingsPage.setTheme('dark')">🌑</button><button class="btn ${u.theme==='light'?'btn-p':'btn-s'}" style="padding:5px 10px;font-size:12px" onclick="SettingsPage.setTheme('light')">☀️</button></div></div>
      </div>
      <div class="sl">Gemini AI</div>
      <div class="card mb14">
        <div class="fg"><label class="fl">API Kalit</label><div class="flex gap8"><input id="gkey" type="password" placeholder="AIza..." value="${g.api_key||''}" oninput="SettingsPage.saveGemini()"><button class="btn btn-s" style="padding:9px 12px;flex-shrink:0" onclick="document.getElementById('gkey').type=document.getElementById('gkey').type==='password'?'text':'password'">👁️</button></div></div>
        <div class="fg"><label class="fl">Harorat: <span id="tv">${g.temperature||0.7}</span></label><input id="gtemp" type="range" min="0.1" max="1" step="0.1" value="${g.temperature||0.7}" oninput="document.getElementById('tv').textContent=this.value;SettingsPage.saveGemini()" style="padding:8px 0"></div>
        <button class="btn btn-p btn-w" style="margin-top:4px" onclick="SettingsPage.testAPI()">🧪 Tekshirish</button>
      </div>
      <div class="sl">Xavfsizlik</div>
      <div class="lg mb14">
        <div class="li"><div class="li-ic" style="background:rgba(191,90,242,.14)">🎭</div><div class="li-c"><div class="li-t">Yuz tekshiruvi</div><div class="li-s">${u.faceRegistered?'✅ Ro\'yxatdan o\'tilgan':'Ro\'yxatdan o\'tilmagan'}</div></div><button class="btn ${u.faceRegistered?'btn-d':'btn-p'}" style="padding:7px 11px;font-size:12px" onclick="SettingsPage.faceSetup()">${u.faceRegistered?'🗑️ Bekor':'📸 Sozlash'}</button></div>
        <div class="li" onclick="SettingsPage.changePIN()" style="cursor:pointer"><div class="li-ic" style="background:rgba(255,159,10,.14)">🔢</div><div class="li-c"><div class="li-t">6 raqamli PIN</div></div><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--t3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></div>
        <div class="li"><div class="li-ic" style="background:rgba(48,209,88,.14)">🔐</div><div class="li-c"><div class="li-t">AES-256 shifrlash</div></div><div class="badge b-green">Faol</div></div>
      </div>
      <div class="sl">Bildirishnomalar va tovush</div>
      <div class="lg mb14">${[['tasks','✅','Vazifalar'],['health','💊',"Sog'liq"],['motivation','💪','Motivatsiya'],['ramadan','🌙','Ramazon'],['sound','🔔','Tovush'],['vibration','📳','Tebranish']].map(([k,e,l])=>`<div class="li"><div class="li-ic" style="background:var(--glass)">${e}</div><div class="li-c"><div class="li-t">${l}</div></div><label class="toggle"><input type="checkbox" ${n[k]?'checked':''} onchange="DB.set('settings.notifications.${k}',this.checked);if('${k}'==='sound'||'${k}'==='vibration'){}else Notif.scheduleAll()"><span class="ts"></span></label></div>`).join('')}
      <div class="li"><div class="li-ic" style="background:rgba(10,132,255,.14)">🔔</div><div class="li-c"><div class="li-t">Rington sinash</div></div><div class="flex gap6">${['task','success','health','ramadan','pomodoro','motivation'].map(r=>`<button class="btn btn-s" style="padding:4px 8px;font-size:11px" onclick="Sound.play('${r}')">${r}</button>`).join('')}</div></div>
      </div>
      <div class="sl">Ma'lumotlar</div>
      <div class="lg mb14">
        <div class="li" onclick="DB.export()" style="cursor:pointer"><div class="li-ic" style="background:rgba(48,209,88,.14)">📤</div><div class="li-c"><div class="li-t">JSON eksport</div></div></div>
        <div class="li"><div class="li-ic" style="background:rgba(10,132,255,.14)">📊</div><div class="li-c"><div class="li-t">CSV eksport</div></div><div class="flex gap5">${[['tasks','Vazifa'],['finance','Moliya'],['nutrition','Ovqat'],['pomodoro','Pomo']].map(([t,l])=>`<button class="btn btn-s" style="padding:4px 8px;font-size:11px" onclick="DB.exportCSV('${t}')">${l}</button>`).join('')}</div></div>
        <div class="li" onclick="document.getElementById('imp-f').click()" style="cursor:pointer"><div class="li-ic" style="background:rgba(10,132,255,.14)">📥</div><div class="li-c"><div class="li-t">JSON import</div></div></div>
        <div class="li" onclick="SettingsPage.clearAll()" style="cursor:pointer"><div class="li-ic" style="background:rgba(255,69,58,.14)">🗑️</div><div class="li-c"><div class="li-t" style="color:var(--red)">Barcha ma'lumotlarni o'chirish</div></div></div>
      </div>
      <input type="file" id="imp-f" accept=".json" style="display:none" onchange="SettingsPage.importData(this)">
      <div style="text-align:center;padding:18px 0;color:var(--t3);font-size:12px">DILI AI v3.0 • gemini-2.5-flash<br>G'iyosiddin Adhamjonov</div>
      <div style="height:16px"></div>
    </div>`;
},
saveGemini(){const key=document.getElementById('gkey')?.value?.trim();const temp=parseFloat(document.getElementById('gtemp')?.value)||.7;if(key!==undefined)DB.set('settings.gemini.api_key',key);DB.set('settings.gemini.temperature',temp)},
async testAPI(){const key=document.getElementById('gkey')?.value?.trim();if(!key)return showToast('API kalitini kiriting!','error');DB.set('settings.gemini.api_key',key);showToast('Tekshirilmoqda...','default');const r=await AI.ask('Salom! Qisqa javob: sen kim?');if(r)showToast('API ishlayapti ✅','success')},
setTheme(t){DB.set('user.theme',t);applyTheme(t);this.render()},
editProfile(){const name=prompt('Ismingiz:',DB.get('user.name')||'');if(name&&name.trim()){DB.set('user.name',name.trim());showToast('Profil yangilandi ✅','success');this.render()}},
async faceSetup(){if(DB.get('user.faceRegistered')){if(await confirm2('Yuz ma\'lumotlarini o\'chirish?')){DB.set('user.faceRegistered',false);DB.set('user.faceDescriptor',null);showToast('Yuz ma\'lumotlari o\'chirildi','default');this.render();}}else{await FaceAuth.register();this.render();}},
changePIN(){const p=prompt('Yangi 6 raqamli PIN:');if(!p||p.length!==6||isNaN(p))return showToast('6 raqamli PIN kiriting!','error');DB.set('settings.security.pin',p);VaultPage.unlocked=false;showToast('PIN yangilandi 🔐','success')},
async clearAll(){if(await confirm2('BARCHA ma\'lumotlar o\'chib ketadi!')){localStorage.removeItem('dili_db_v3');location.reload()}},
async importData(input){const f=input.files[0];if(!f)return;try{await DB.import(f);showToast('Import ✅','success');location.reload()}catch(e){showToast('Import xatosi','error')}input.value=''}
};

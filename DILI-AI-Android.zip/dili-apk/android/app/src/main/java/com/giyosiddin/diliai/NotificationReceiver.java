package com.giyosiddin.diliai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            AndroidBridge bridge = new AndroidBridge(context);
            bridge.showNotification("DILI AI", "Qurilma yoqildi. DILI AI tayyor! 🤖");
        }
    }
}

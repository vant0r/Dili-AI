# DILI AI - Android APK Build Qo'llanmasi

## Loyiha tuzilishi
```
dili-apk/
├── www/                          ← Web app fayllari (DILI AI v3.0)
├── android/                      ← Android native loyiha
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── java/com/giyosiddin/diliai/
│   │   │   │   ├── MainActivity.java     ← Asosiy faoliyat
│   │   │   │   ├── AndroidBridge.java    ← JS↔Native ko'prik
│   │   │   │   └── NotificationReceiver.java
│   │   │   ├── assets/public/            ← Web fayllari bu yerda
│   │   │   ├── res/
│   │   │   │   ├── mipmap-*/             ← Ikonalar
│   │   │   │   ├── layout/               ← XML layoutlar
│   │   │   │   └── values/               ← Ranglar, matnlar
│   │   │   └── AndroidManifest.xml
│   │   ├── build.gradle
│   │   └── proguard-rules.pro
│   ├── gradle/wrapper/
│   ├── build.gradle
│   ├── settings.gradle
│   ├── gradle.properties
│   ├── gradlew
│   └── gradlew.bat
├── icons/                        ← Barcha o'lchamlar
├── capacitor.config.ts
└── package.json
```

---

## USUL 1 — Android Studio (Eng oson) ✅ TAVSIYA

### 1. Android Studio o'rnatish
Yuklab oling: https://developer.android.com/studio

### 2. Loyihani ochish
1. Android Studio ni oching
2. **"Open"** → `dili-apk/android/` papkasini tanlang
3. Gradle sync kutib turing (1-3 daqiqa)

### 3. APK build qilish
**Debug APK (test uchun):**
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
```
APK joyi: `android/app/build/outputs/apk/debug/app-debug.apk`

**Release APK (Play Store uchun):**
```
Build → Generate Signed Bundle/APK → APK → Next
```
Keystore yaratish yoki mavjudini tanlash → Finish

---

## USUL 2 — Command Line

### Talablar
```bash
# Java 17+ o'rnatish
sudo apt install openjdk-17-jdk   # Ubuntu/Debian
brew install openjdk@17            # macOS

# Android SDK o'rnatish
# https://developer.android.com/tools/sdkmanager
```

### Environment o'rnatish
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

### Gradle wrapper yuklab olish
```bash
cd android
# Linux/Mac:
curl -o gradle/wrapper/gradle-wrapper.jar \
  https://github.com/gradle/gradle/raw/v8.4.0/gradle/wrapper/gradle-wrapper.jar
chmod +x gradlew
```

### Build qilish
```bash
# Debug APK
cd android
./gradlew assembleDebug

# Release APK
./gradlew assembleRelease

# APK joyi
ls app/build/outputs/apk/debug/app-debug.apk
ls app/build/outputs/apk/release/app-release.apk
```

### Telefonга o'rnatish
```bash
# USB orqali
adb install app/build/outputs/apk/debug/app-debug.apk

# Yoki APK faylni telefonga ko'chiring va "Noma'lum manbalar" dan o'rnating
```

---

## USUL 3 — Online Build (Eng tez, hech narsa o'rnatmasdan)

### Appetize.io (Test uchun)
1. https://appetize.io ga kiring
2. `www/` papkasini ZIP qilib yuklang
3. Online test qiling

### GitHub Actions (Avtomatik APK)
1. GitHub repoga push qiling
2. `.github/workflows/build.yml` fayli ishga tushadi
3. APK artifacts dan yuklab oling

Quyidagi `.github/workflows/build.yml` ni yarating:
```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Build APK
        run: |
          cd android
          chmod +x gradlew
          ./gradlew assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: DILI-AI-debug.apk
          path: android/app/build/outputs/apk/debug/app-debug.apk
```

---

## USUL 4 — Budibase / Gonative (Tayyor servis)

**GoNative.io** (Eng tez APK):
1. https://gonative.io ga kiring
2. URL: `https://diliai.x10host.com` kiriting
3. Icon yuklang (icons/icon-512.png)
4. APK yuklab oling

---

## Release APK imzolash (Keystore)

```bash
# Keystore yaratish
keytool -genkey -v \
  -keystore android/app/keystore/dili-ai.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias diliai \
  -dname "CN=Giyosiddin Adhamjonov, OU=DILI AI, O=GA, L=Toshkent, S=Toshkent, C=UZ"

# Parol: diliai2025 (yoki o'zingiz belgilang)
```

---

## APK sozlamalari

| Parametr | Qiymat |
|----------|--------|
| App ID | `com.giyosiddin.diliai` |
| App Name | `DILI AI` |
| Version | `3.0.0` (code: 3) |
| Min Android | 6.0 (API 23) |
| Target Android | 14 (API 34) |
| Icon | Gradient blue-purple robot |
| Ruxsatlar | Kamera, Bildirishnoma, Tebranish |

---

## Muammo yechimi

**"SDK not found" xatosi:**
```bash
echo "sdk.dir=$HOME/Android/Sdk" > android/local.properties
```

**"Gradle build failed":**
```bash
cd android && ./gradlew clean && ./gradlew assembleDebug
```

**"Camera not working on device":**
- Settings → Apps → DILI AI → Permissions → Camera → Allow

---

## Natija
✅ Debug APK: ~15-20 MB  
✅ Release APK (minified): ~8-12 MB  
✅ Min Android: 6.0+  
✅ Kamera (Yuz tekshiruvi): ✓  
✅ Bildirishnomalar: ✓  
✅ Offline rejim: ✓  
✅ LocalStorage: ✓  
